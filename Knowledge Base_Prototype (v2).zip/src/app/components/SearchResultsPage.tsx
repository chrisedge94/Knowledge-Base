import { Link, useSearchParams } from "react-router-dom";
import svgPaths from "@/imports/svg-m795sxqv7p";
import { useState, useRef, useEffect } from "react";
import Group2134098350 from "@/imports/Group2134098350";
import BackToKnowledgeBase from "@/imports/Link";
import { NotificationsButton } from "./NotificationsButton";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";

export function SearchResultsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "sustainability");
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<string>("All Types");
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const languageDropdownRef = useRef<HTMLDivElement>(null);
  const searchDropdownRef = useRef<HTMLDivElement>(null);

  // Sustainability-related search suggestions
  const allSuggestions = [
    "Carbon Footprint",
    "Greenhouse Gas Emissions",
    "Renewable Energy",
    "ESG Reporting",
    "Supply Chain Sustainability",
    "Circular Economy",
    "Net Zero Goals",
    "Energy Efficiency",
    "Sustainable Procurement",
    "Climate Risk Assessment",
    "Waste Management",
    "Water Conservation",
    "Biodiversity",
    "Social Responsibility",
    "Green Building",
  ];

  const languageOptions = [
    { code: "en-US", label: "English (US)" },
    { code: "es-ES", label: "Español (Spanish)" },
    { code: "fr-FR", label: "Français (French)" },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (languageDropdownRef.current && !languageDropdownRef.current.contains(event.target as Node)) {
        setIsLanguageDropdownOpen(false);
      }
      if (searchDropdownRef.current && !searchDropdownRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: searchQuery });
    setShowSuggestions(false);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    setShowSuggestions(value.length > 0);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    setShowSuggestions(false);
    setSearchParams({ q: suggestion });
  };

  const handleViewMore = () => {
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery });
    }
    setShowSuggestions(false);
  };

  // Filter suggestions based on search query
  const filteredSuggestions = searchQuery.trim()
    ? allSuggestions.filter(suggestion =>
        suggestion.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : allSuggestions.slice(0, 5);

  // Dummy search results
  const allSearchResults = [
    {
      id: "1",
      title: "Foundation of Sustainability and ESG",
      category: "Sustainability and ESG",
      type: "Sustainability",
      excerpt: "Learn about the fundamental concepts of sustainability and Environmental, Social, and Governance (ESG) principles. This comprehensive guide covers the basics of sustainable practices and how they apply to your organization.",
      relevance: 98
    },
    {
      id: "2",
      title: "Sustainability Reporting and Metrics",
      category: "Dashboard and Analytics",
      type: "Sustainability",
      excerpt: "Discover how to track and report on sustainability metrics using Resource Advisor+. This article explains key performance indicators (KPIs) and how to create meaningful sustainability reports.",
      relevance: 95
    },
    {
      id: "3",
      title: "Implementing Sustainability Initiatives",
      category: "Supply Chain Management",
      type: "Sustainability",
      excerpt: "A step-by-step guide to implementing sustainability initiatives across your supply chain. Learn best practices for engaging suppliers and measuring environmental impact.",
      relevance: 92
    },
    {
      id: "4",
      title: "Carbon Footprint and Sustainability Goals",
      category: "Carbon Footprint and Emissions",
      type: "Sustainability",
      excerpt: "Understand how carbon footprint calculations contribute to your overall sustainability strategy. This article covers setting goals, tracking progress, and achieving carbon neutrality.",
      relevance: 89
    },
    {
      id: "5",
      title: "SERA AI Assistant for Sustainability Insights",
      category: "SERA",
      type: "Product Guides",
      excerpt: "Learn how SERA AI Assistant can help you analyze sustainability data and provide actionable insights. This guide covers natural language queries and automated recommendations.",
      relevance: 86
    },
    {
      id: "6",
      title: "Data Visualization for Sustainability Metrics",
      category: "Dashboard and Analytics",
      type: "Product Guides",
      excerpt: "Create compelling visualizations of your sustainability data. This tutorial covers charts, graphs, and dashboards that communicate your sustainability performance effectively.",
      relevance: 83
    },
  ];

  // Filter results based on selected type and category
  const searchResults = allSearchResults.filter((result) => {
    const typeMatch = selectedType === "All Types" || result.type === selectedType;
    const categoryMatch = selectedCategory === "All Categories" || result.category === selectedCategory;
    return typeMatch && categoryMatch;
  });

  // Calculate counts for each type
  const typeCounts = {
    "All Types": allSearchResults.length,
    "Sustainability": allSearchResults.filter(r => r.type === "Sustainability").length,
    "Product Guides": allSearchResults.filter(r => r.type === "Product Guides").length,
  };

  // Get unique categories and their counts
  const categoryList = Array.from(new Set(allSearchResults.map(r => r.category)));
  const categoryCounts: Record<string, number> = {
    "All Categories": allSearchResults.length,
  };
  categoryList.forEach(cat => {
    categoryCounts[cat] = allSearchResults.filter(r => r.category === cat).length;
  });

  return (
    <div className="bg-[#f4f6f8] min-h-screen relative w-full">
      {/* Header */}
      <div className="bg-white border-b border-[#d4d8d9] border-solid h-[143px] relative flex items-center px-[40px] justify-between">
        <div className="flex items-center gap-[56px]">
          <div className="relative size-[74px]">
            {/* Logo Icon */}
            <div className="absolute left-0 top-[4.62px] w-[73.993px] h-[64.757px]">
              <div className="size-full">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73.9904 64.7573">
                  <path d={svgPaths.p23306380} fill="#087959" stroke="white" strokeWidth="0.500003" />
                </svg>
              </div>
            </div>
          </div>
          
          <p className="font-['Nunito:Bold',sans-serif] font-bold leading-[44px] text-[#087959] text-[64px]">
            Resource Advisor+ Knowledge Base
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex gap-[21px] items-center">
          <button className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[200px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center px-[12px]">
            <div className="flex items-center gap-[8px]">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="flex-shrink-0">
                <path d="M15 10H5M5 10L10 15M5 10L10 5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="whitespace-nowrap">Back to RA+</span>
            </div>
          </button>
          
          <div ref={languageDropdownRef} className="relative">
            <button
              className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[213px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center gap-[8px] px-[16px]"
              onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
            >
              <span>English (US)</span>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M5 7.5L10 12.5L15 7.5" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
              </svg>
            </button>
            {isLanguageDropdownOpen && (
              <div className="absolute right-0 top-[44px] w-[213px] bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50">
                {languageOptions.map((option) => (
                  <button
                    key={option.code}
                    className="w-full text-left px-[16px] py-[12px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[18px] text-[#090b0c] hover:bg-[#f0f9f7] first:rounded-t-[4px] last:rounded-b-[4px] transition-colors"
                    onClick={() => {
                      setIsLanguageDropdownOpen(false);
                    }}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-[8px] items-center">
            <NotificationsButton />

            <Link to="/profile" className="relative size-[40px] hover:opacity-80 transition-opacity cursor-pointer">
              <div className="bg-[#676f73] rounded-full size-[40px] flex items-center justify-center">
                <span className="font-['Nunito_Sans:Bold',sans-serif] font-bold text-[18px] text-white">MA</span>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-[56px] py-[40px]">
        {/* Back to Knowledge Base Link */}
        <Link to="/" className="inline-block mb-[16px]">
          <div className="w-[210px] h-[24px]">
            <BackToKnowledgeBase />
          </div>
        </Link>

        {/* Breadcrumb */}
        <div className="mb-[24px]">
          <div className="flex items-center gap-[8px]">
            <Link to="/" className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] underline hover:text-[#087959]">
              Homepage
            </Link>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73]">/</span>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73]">Search Results</span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mb-[40px]">
          <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[64px] text-black leading-[70px] mb-[32px]">
            Search Results
          </h1>
          
          <div className="relative" ref={searchDropdownRef}>
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchChange}
                onFocus={() => searchQuery.length > 0 && setShowSuggestions(true)}
                placeholder="Search"
                className="w-full h-[74px] bg-white border border-[#676f73] border-solid rounded-[4px] px-[31px] pr-[80px] font-['Nunito_Sans:Regular',sans-serif] text-[28px] text-[#090b0c] focus:outline-none focus:border-[#087959]"
              />
              <button type="submit" className="absolute right-[10px] top-[7px] w-[60px] h-[60px]">
                <Group2134098350 />
              </button>
            </form>

            {/* Search Suggestions Dropdown */}
            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute top-[78px] left-0 right-0 bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50 overflow-hidden">
                {filteredSuggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="w-full text-left px-[31px] py-[14px] font-['Nunito_Sans:Regular',sans-serif] text-[20px] text-[#090b0c] hover:bg-[#f0f9f7] transition-colors border-b border-[#e8eaeb] last:border-b-0"
                  >
                    {suggestion}
                  </button>
                ))}
                
                {/* View More Button */}
                <button
                  onClick={handleViewMore}
                  className="w-full px-[31px] py-[16px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] text-[#087959] hover:bg-[#f0f9f7] transition-colors border-t-2 border-[#d4d8d9]"
                >
                  View More →
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Results Header */}
        <div className="mb-[32px]">.
          <p className="font-['Nunito:Regular',sans-serif] text-[24px] text-[#676f73]">
            <span className="font-['Nunito:Bold',sans-serif] text-[#087959]">{searchResults.length} results</span> for "{searchParams.get("q") || "sustainability"}" in All Categories
          </p>
        </div>

        {/* Two Column Layout: Filters + Results */}
        <div className="flex gap-[40px] mb-[56px]">
          {/* Left Sidebar - Filters */}
          <div className="w-[280px] flex-shrink-0">
            {/* Type Filter */}
            <div className="mb-[32px]">
              <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-[#090b0c] mb-[16px]">
                Type
              </h3>
              <div className="space-y-[8px]">
                {Object.entries(typeCounts).map(([type, count]) => (
                  <button
                    key={type}
                    onClick={() => setSelectedType(type)}
                    className={`w-full text-left px-[16px] py-[10px] rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] transition-colors ${
                      selectedType === type
                        ? "bg-[#f0f9f7] text-[#087959] font-bold"
                        : "bg-white text-[#676f73] hover:bg-[#f5f8fa]"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{type}</span>
                      <span className="text-[14px]">({count})</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-[#090b0c] mb-[16px]">
                By Category
              </h3>
              <div className="space-y-[8px]">
                <button
                  onClick={() => setSelectedCategory("All Categories")}
                  className={`w-full text-left px-[16px] py-[10px] rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] transition-colors ${
                    selectedCategory === "All Categories"
                      ? "bg-[#f0f9f7] text-[#087959] font-bold"
                      : "bg-white text-[#676f73] hover:bg-[#f5f8fa]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>All Categories</span>
                    <span className="text-[14px]">({categoryCounts["All Categories"]})</span>
                  </div>
                </button>
                {categoryList.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`w-full text-left px-[16px] py-[10px] rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] transition-colors ${
                      selectedCategory === category
                        ? "bg-[#f0f9f7] text-[#087959] font-bold"
                        : "bg-white text-[#676f73] hover:bg-[#f5f8fa]"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{category}</span>
                      <span className="text-[14px]">({categoryCounts[category]})</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Side - Search Results */}
          <div className="flex-1">
            <div className="space-y-[24px]">
          {searchResults.map((result) => (
            <Link
              key={result.id}
              to={`/article/${result.id}`}
              className="block bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[32px] hover:shadow-lg hover:border-[#087959] transition-all"
            >
              <div className="flex items-start justify-between mb-[12px]">
                <div className="flex-1">
                  <div className="flex items-center gap-[12px] mb-[8px]">
                    <span className="bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[14px] px-[12px] py-[4px] rounded-[4px]">
                      {result.category}
                    </span>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73]">
                      {result.relevance}% relevant
                    </span>
                  </div>
                  <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[36px] text-[#087959] leading-[44px] mb-[12px]">
                    {result.title}
                  </h2>
                  <p className="font-['Nunito:Regular',sans-serif] text-[20px] text-[#090b0c] leading-[28px]">
                    {result.excerpt}
                  </p>
                </div>
                <div className="ml-[24px] flex-shrink-0">
                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <path d={svgPaths.p1e5dc800} fill="#087959" />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
            </div>
          </div>
        </div>

        {/* Helpful Resources Section */}
        <div className="bg-[#087959] rounded-[4px] p-[40px] mb-[56px]">
          <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[44px] text-white leading-[52px] mb-[24px]">
            Can't find what you're looking for?
          </h2>
          <p className="font-['Nunito:Regular',sans-serif] text-[24px] text-white leading-[32px] mb-[32px]">
            Try refining your search or explore our popular topics and categories.
          </p>
          <div className="flex gap-[16px]">
            <Link
              to="/"
              className="bg-white border border-[#087959] border-solid rounded-[4px] h-[50px] px-[32px] text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center gap-[8px] hover:bg-[#f0f9f7] transition-colors"
            >
              <span>Browse All Topics</span>
            </Link>
            <Link
              to="/contact"
              className="bg-[#087959] border-2 border-white border-solid rounded-[4px] h-[50px] px-[32px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center gap-[8px] hover:bg-[#0a9570] transition-colors"
            >
              <span>Contact Support</span>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M5 10H15M15 10L10 5M15 10L10 15" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      {/* ChatBot */}
      <ChatBot />
    </div>
  );
}