import svgPaths from "./svg-bscy2w8k00";

function Icon() {
  return (
    <div className="h-[2.014px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0174 2.01389">
        <path d={svgPaths.pa591800} fill="var(--fill-0, #087959)" id="Vector" />
      </svg>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2.014px] items-start left-[5.99px] top-[7.99px] w-[20.017px]" data-name="Container">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="h-[16.042px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.02778 16.0417">
        <path d={svgPaths.p1910f8c0} fill="var(--fill-0, #087959)" id="Vector" />
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[16.042px] items-start left-[3.99px] top-[0.99px] w-[9.028px]" data-name="Container">
      <Icon1 />
    </div>
  );
}

function Container2() {
  return (
    <div className="relative size-full" data-name="Container">
      <Container />
      <Container1 />
    </div>
  );
}

function Icon2() {
  return (
    <></>
  );
}

export default function Group() {
  return (
    <div className="relative size-full">
      <Icon2 />
    </div>
  );
}