import { useState, useRef, useEffect } from "react";
import svgPaths from "@/imports/svg-5wwadq0jak";
import { Send, X, Minimize2 } from "lucide-react";

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ text: string; sender: "user" | "sera" }[]>([
    {
      text: "Hello! I'm SERA, your AI assistant for Resource Advisor+. How can I help you today?",
      sender: "sera",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    // Add user message
    const newMessages = [...messages, { text: inputValue, sender: "user" as const }];
    setMessages(newMessages);
    setInputValue("");

    // Simulate SERA response
    setTimeout(() => {
      const responses = [
        "I can help you with that! Let me find the relevant information for you.",
        "That's a great question. Based on your query, I recommend checking our documentation on this topic.",
        "I'm here to assist you with Resource Advisor+. Could you provide more details about what you're looking for?",
        "I found several articles that might help. Would you like me to show them to you?",
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setMessages((prev) => [...prev, { text: randomResponse, sender: "sera" }]);
    }, 1000);
  };

  return (
    <>
      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-[120px] right-[40px] w-[400px] h-[600px] bg-white border-2 border-[#087959] rounded-[12px] shadow-2xl flex flex-col z-50">
          {/* Header */}
          <div className="bg-[#087959] rounded-t-[10px] p-[20px] flex items-center justify-between">
            <div className="flex items-center gap-[12px]">
              <div className="size-[40px] bg-white rounded-full flex items-center justify-center">
                <svg className="block size-[32px]" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
                  <g clipPath="url(#clip0_chat)">
                    <path d={svgPaths.p254bb80} fill="#087959" />
                  </g>
                  <defs>
                    <clipPath id="clip0_chat">
                      <rect fill="white" height="80" width="80" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
              <div>
                <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-white">
                  SERA
                </h3>
                <p className="font-['Nunito:Regular',sans-serif] text-[12px] text-white opacity-90">
                  AI Assistant
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-[#0a9570] rounded-full p-[8px] transition-colors"
            >
              <X className="size-[20px]" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-[20px] space-y-[16px] bg-[#f5f8fa]">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] rounded-[12px] px-[16px] py-[12px] ${
                    message.sender === "user"
                      ? "bg-[#087959] text-white"
                      : "bg-white border border-[#d4d8d9]"
                  }`}
                >
                  <p
                    className={`font-['Nunito:Regular',sans-serif] text-[14px] leading-[20px] ${
                      message.sender === "user" ? "text-white" : "text-[#090b0c]"
                    }`}
                  >
                    {message.text}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSendMessage} className="p-[20px] bg-white border-t border-[#d4d8d9]">
            <div className="flex gap-[8px]">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 border border-[#d4d8d9] rounded-[8px] px-[16px] py-[12px] font-['Nunito:Regular',sans-serif] text-[14px] focus:outline-none focus:border-[#087959]"
              />
              <button
                type="submit"
                className="bg-[#087959] text-white rounded-[8px] px-[16px] py-[12px] hover:bg-[#0a9570] transition-colors flex items-center justify-center"
              >
                <Send className="size-[20px]" />
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-[40px] right-[40px] size-[80px] bg-[#087959] rounded-full shadow-2xl hover:scale-110 transition-transform z-50 flex items-center justify-center border-4 border-white"
        aria-label="Open SERA Chat"
      >
        <svg className="block size-[80px]" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
          <g clipPath="url(#clip0_23_2403)">
            <path d={svgPaths.p254bb80} fill="white" />
          </g>
          <defs>
            <clipPath id="clip0_23_2403">
              <rect fill="white" height="80" width="80" />
            </clipPath>
          </defs>
        </svg>
      </button>
    </>
  );
}
