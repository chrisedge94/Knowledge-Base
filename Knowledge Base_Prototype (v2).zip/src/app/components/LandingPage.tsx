import { Link, useNavigate } from "react-router-dom";
import svgPaths from "@/imports/svg-m795sxqv7p";
import imgImage from "figma:asset/3cadefd4e2c9f583a0a4cb744a21e2d803bba14b.png";
import imgImage7 from "figma:asset/87b4d70e637a0645d999eae543620bd263b014f6.png";
import imgImage11 from "figma:asset/57de2e60718d00053a32b731dc88426fadb06485.png";
import { imgVision } from "@/imports/svg-nhp3t";
import { useState, useRef, useEffect } from "react";
import ShareIcon from "@/imports/ShareIcon3";
import Group2134098350 from "@/imports/Group2134098350";
import { NotificationsButton } from "./NotificationsButton";
import { Search } from "lucide-react";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";

export function LandingPage() {
  const navigate = useNavigate();
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const languageDropdownRef = useRef<HTMLDivElement>(null);
  const searchDropdownRef = useRef<HTMLDivElement>(null);

  // Sustainability-related search suggestions
  const allSuggestions = [
    "Carbon Footprint",
    "Greenhouse Gas Emissions",
    "Renewable Energy",
    "ESG Reporting",
    "Supply Chain Sustainability",
    "Circular Economy",
    "Net Zero Goals",
    "Energy Efficiency",
    "Sustainable Procurement",
    "Climate Risk Assessment",
    "Waste Management",
    "Water Conservation",
    "Biodiversity",
    "Social Responsibility",
    "Green Building",
  ];

  const languageOptions = [
    { code: "en-US", label: "English (US)" },
    { code: "es-ES", label: "Español (Spanish)" },
    { code: "fr-FR", label: "Français (French)" },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (languageDropdownRef.current && !languageDropdownRef.current.contains(event.target as Node)) {
        setIsLanguageDropdownOpen(false);
      }
      if (searchDropdownRef.current && !searchDropdownRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const popularTopics = [
    { id: "1", title: "Introduction to SERA AI Assistant", icon: "share" },
    { id: "2", title: "Foundation of Sustainability and ESG", icon: "compass" },
    { id: "3", title: "Quick start guide to Upload Data for Visualizations", icon: "upload" },
    { id: "4", title: "Quick start guide to Download Data for Visualizations", icon: "download" },
  ];

  const topicCards = [
    { id: "home-navigation", title: "Home and Navigation" },
    { id: "sera", title: "SERA" },
    { id: "dashboard-analytics", title: "Dashboard and Analytics" },
    { id: "carbon-emissions", title: "Carbon Footprint and Emissions" },
    { id: "supply-chain", title: "Supply Chain Management" },
    { id: "sustainability-esg", title: "Sustainability and ESG" },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setShowSuggestions(false);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    setShowSuggestions(value.length > 0);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    setShowSuggestions(false);
    navigate(`/search?q=${encodeURIComponent(suggestion)}`);
  };

  const handleViewMore = () => {
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    } else {
      navigate('/search');
    }
    setShowSuggestions(false);
  };

  // Filter suggestions based on search query
  const filteredSuggestions = searchQuery.trim()
    ? allSuggestions.filter(suggestion =>
        suggestion.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : allSuggestions.slice(0, 5);

  return (
    <div className="bg-[#f4f6f8] min-h-screen relative w-full">
      {/* Header */}
      <div className="bg-white border-b border-[#d4d8d9] border-solid h-[143px] relative flex items-center px-[40px] justify-between">
        <div className="flex items-center gap-[56px]">
          <div className="relative size-[74px]">
            {/* Logo Icon */}
            <div className="absolute left-0 top-[4.62px] w-[73.993px] h-[64.757px]">
              <div className="size-full">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73.9904 64.7573">
                  <path d={svgPaths.p23306380} fill="#087959" stroke="white" strokeWidth="0.500003" />
                </svg>
              </div>
            </div>
          </div>
          
          <p className="font-['Nunito:Bold',sans-serif] font-bold leading-[60px] text-[#087959] text-[64px]">
            Resource Advisor+ Knowledge Base
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex gap-[21px] items-center">
          <button className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[200px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center px-[12px]">
            <div className="flex items-center gap-[8px]">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="flex-shrink-0">
                <path d="M15 10H5M5 10L10 15M5 10L10 5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="whitespace-nowrap">Back to RA+</span>
            </div>
          </button>
          
          <div ref={languageDropdownRef} className="relative">
            <button
              className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[213px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center gap-[8px] px-[16px]"
              onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
            >
              <span>English (US)</span>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M5 7.5L10 12.5L15 7.5" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
              </svg>
            </button>
            {isLanguageDropdownOpen && (
              <div className="absolute right-0 top-[44px] w-[213px] bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50">
                {languageOptions.map((option) => (
                  <button
                    key={option.code}
                    className="w-full text-left px-[16px] py-[12px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[18px] text-[#090b0c] hover:bg-[#f0f9f7] first:rounded-t-[4px] last:rounded-b-[4px] transition-colors"
                    onClick={() => {
                      setIsLanguageDropdownOpen(false);
                      // Add logic to change language here
                    }}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-[8px] items-center">
            <NotificationsButton />

            <Link to="/profile" className="relative size-[40px] hover:opacity-80 transition-opacity cursor-pointer">
              <div className="bg-[#676f73] rounded-full size-[40px] flex items-center justify-center">
                <span className="font-['Nunito_Sans:Bold',sans-serif] font-bold text-[18px] text-white">MA</span>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-[56px] py-[40px]">
        {/* Hero Section */}
        <div className="relative h-[477px] mb-[24px]">
          {/* Background Image */}
          <div className="absolute inset-x-0 top-0 h-[381px] overflow-hidden rounded-[4px]">
            <img src={imgImage} alt="" className="w-full h-full object-cover" />
          </div>

          <div className="relative z-10 flex gap-[51px] justify-between">
            {/* Left Side - Search */}
            <div className="w-[880px]">
              <div className="mb-[47px]">
                <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] underline mb-[6px]">Homepage</p>
                
                <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-black leading-[68px] mb-[0px] whitespace-nowrap">
                  Looking for answers?
                </h1>
                <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-black leading-[68px]">
                  We're here for you
                </h1>
              </div>

              <div className="relative" ref={searchDropdownRef}>
                <form onSubmit={handleSearch}>
                  <input
                    type="text"
                    placeholder="Search"
                    value={searchQuery}
                    onChange={handleSearchChange}
                    onFocus={() => searchQuery.length > 0 && setShowSuggestions(true)}
                    className="w-full h-[56px] bg-white border border-[#676f73] border-solid rounded-[4px] px-[24px] pr-[70px] font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#676f73] focus:outline-none focus:border-[#087959]"
                  />
                  <button 
                    type="submit"
                    className="absolute right-[7px] top-[7px] w-[42px] h-[42px] bg-[#087959] rounded-full flex items-center justify-center hover:bg-[#0a9570] transition-colors"
                  >
                    <Search className="w-[20px] h-[20px] text-white" />
                  </button>
                </form>

                {/* Search Suggestions Dropdown */}
                {showSuggestions && filteredSuggestions.length > 0 && (
                  <div className="absolute top-[60px] left-0 right-0 bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50 overflow-hidden">
                    {filteredSuggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="w-full text-left px-[24px] py-[12px] font-['Nunito_Sans:Regular',sans-serif] text-[16px] text-[#090b0c] hover:bg-[#f0f9f7] transition-colors border-b border-[#e8eaeb] last:border-b-0"
                      >
                        {suggestion}
                      </button>
                    ))}
                    
                    {/* View More Button */}
                    <button
                      onClick={handleViewMore}
                      className="w-full px-[24px] py-[14px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[16px] text-[#087959] hover:bg-[#f0f9f7] transition-colors border-t-2 border-[#d4d8d9]"
                    >
                      View More →
                    </button>
                  </div>
                )}
              </div>

              <div className="rounded-[4px] px-[16px] py-[16px] mt-[8px]">
                <p className="font-['Arimo:Regular',sans-serif] text-[20px] leading-[28px]">
                  <span className="font-bold">Keywords: </span>
                  <button 
                    onClick={() => setSearchQuery('SERA')}
                    className="underline hover:text-[#087959] cursor-pointer transition-colors text-[18px]"
                  >
                    SERA
                  </button>
                  <span>, </span>
                  <button 
                    onClick={() => setSearchQuery('Product Tutorial')}
                    className="underline hover:text-[#087959] cursor-pointer transition-colors text-[18px]"
                  >
                    Product Tutorial
                  </button>
                  <span>, </span>
                  <button 
                    onClick={() => setSearchQuery('Upload Data')}
                    className="underline hover:text-[#087959] cursor-pointer transition-colors text-[18px]"
                  >
                    Upload Data
                  </button>
                </p>
              </div>
            </div>

            {/* Right Side - Popular Topics */}
            <div className="w-[847px]">
              <div className="bg-[#087959] rounded-[4px] h-[430px] p-[24px] flex flex-col">
                <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-white leading-[44px] underline">
                  Popular Topics
                </h2>

                <div className="flex flex-col justify-between flex-1 pt-[40px] pb-[24px]">
                  {popularTopics.map((topic, index) => (
                    <Link
                      key={index}
                      to={`/article/${topic.id}`}
                      className="flex items-center gap-[16px] h-[56px] hover:bg-[#0a9570] transition-colors group"
                    >
                      <div className="size-[50px] flex items-center justify-center flex-shrink-0">
                        <div className="bg-[#eff3f9] rounded-full size-[44px] flex items-center justify-center">
                          {topic.icon === "share" && (
                            <svg width="24" height="24" viewBox="0 0 32 32" fill="none">
                              <path d={svgPaths.p28dd1f00} fill="#090B0C" />
                            </svg>
                          )}
                          {topic.icon === "compass" && (
                            <svg width="20" height="20" viewBox="0 0 27 27" fill="none">
                              <path d={svgPaths.p30fb9600} fill="black" />
                            </svg>
                          )}
                          {topic.icon === "upload" && (
                            <div className="bg-[#eff3f9] rounded-full size-[44px] flex items-center justify-center">
                              <div className="w-[24px]">
                              <ShareIcon />
                              </div>
                            </div>
                          )}
                          {topic.icon === "download" && (
                            <div className="w-[24px]">
                              <ShareIcon />
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <p className="font-['Nunito:Regular',sans-serif] text-[20px] text-white leading-[28px]">
                          {topic.title}
                        </p>
                      </div>

                      <div className="size-[40px] flex items-center justify-center flex-shrink-0">
                        <svg width="20" height="20" viewBox="0 0 30 30" fill="none">
                          <path d={svgPaths.p1e5dc800} fill="white" />
                        </svg>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Welcome Section */}
        <div className="border border-[#d4d8d9] border-solid rounded-[4px] h-[552px] mb-[56px] flex overflow-hidden">
          <div className="w-[840px]">
            <img src={imgImage7} alt="Knowledge Hub" className="w-full h-full object-cover rounded-l-[4px]" />
          </div>
          <div className="flex-1 bg-white p-[48px] flex flex-col justify-center">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-black leading-[48px] mb-[24px]">
              Welcome to the Resource Advisor+ Knowledge Hub
            </h2>
            <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-black leading-[28px]">
              Our mission is to simplify Sustainability and Decarbonization topics for you! We've put in a lot of effort to ensure Resource Advisor+ is as user-friendly as possible, but we understand you might still have questions. The good news? Real people are here behind the scenes, ready to assist you. Take your time exploring our Knowledge Hub, and if you you need any further assistance, don't hesitate to reach out.
            </p>
          </div>
        </div>

        {/* Topics Section */}
        <div className="mb-[56px]">
          <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-black leading-[48px] mb-[40px]">
            Topics
          </h2>
          
          <div className="grid grid-cols-3 gap-[83px]">
            {topicCards.map((topic, index) => (
              <Link
                key={index}
                to={`/topic/${topic.id}`}
                className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] h-[280px] flex flex-col items-center justify-center hover:shadow-lg transition-shadow"
              >
                <div className="bg-[#087959] size-[100px] rounded-full flex items-center justify-center mb-[24px]">
                  <svg width="50" height="50" viewBox="0 0 80 80" fill="none">
                    <path d={svgPaths.p768e080} fill="white" />
                  </svg>
                </div>
                <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] text-[#087959] text-center leading-[38px] px-[24px]">
                  {topic.title}
                </h3>
              </Link>
            ))}
          </div>
        </div>

        {/* Contact and Social Section */}
        <div className="border border-[#d4d8d9] border-solid rounded-[4px] h-[552px] flex overflow-hidden">
          <div className="w-[967px]">
            <img src={imgImage11} alt="Customer First" className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 bg-white p-[48px]">
            <div className="mb-[48px]">
              <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-black leading-[48px] mb-[16px]">
                Contact Support
              </h3>
              <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-black leading-[28px] mb-[32px]">
                Ideally, contact us directly from Resource Advisor+. Alternatively, our team of experts can assist you via our contact forms!
              </p>
              <Link
                to="/contact"
                className="bg-[#087959] border border-white border-solid rounded-[4px] h-[44px] px-[20px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[16px] flex items-center justify-center gap-[8px] w-[170px] mx-auto"
              >
                <span>Contact Us!</span>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
                  <path d="M5 10H15M15 10L10 5M15 10L10 15" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </Link>
            </div>

            <div>
              <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-black leading-[44px] mb-[12px]">
                Follow us on Social Media
              </h3>
              <div className="flex gap-[24px] justify-center">
                <a href="#" className="size-[60px]" aria-label="Facebook">
                  <svg className="size-full" viewBox="0 0 100 100" fill="none">
                    <path d={svgPaths.p25597c80} fill="#087959" />
                  </svg>
                </a>
                <a href="#" className="size-[60px]" aria-label="Twitter">
                  <svg className="size-full" viewBox="0 0 100 100" fill="none">
                    <path d={svgPaths.p3070b200} fill="#087959" />
                  </svg>
                </a>
                <a href="#" className="size-[60px]" aria-label="Instagram">
                  <svg className="size-full" viewBox="0 0 100 100" fill="none">
                    <path d={svgPaths.p9aaa540} fill="#087959" />
                  </svg>
                </a>
                <a href="#" className="size-[60px]" aria-label="LinkedIn">
                  <svg className="size-full" viewBox="0 0 100 100" fill="none">
                    <path d={svgPaths.p24147000} fill="#087959" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      {/* ChatBot */}
      <ChatBot />
    </div>
  );
}