import svgPaths from "./svg-07n4l0j7g2";
import imgImage from "figma:asset/3cadefd4e2c9f583a0a4cb744a21e2d803bba14b.png";
import imgImage7 from "figma:asset/87b4d70e637a0645d999eae543620bd263b014f6.png";
import imgImage11 from "figma:asset/57de2e60718d00053a32b731dc88426fadb06485.png";
import { imgVector, imgVision } from "./svg-ecp4b";

function Icon() {
  return (
    <div className="h-[64.757px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[0.39%_0.34%]" data-name="Vector">
        <div className="absolute inset-[-0.39%_-0.34%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73.9904 64.7573">
            <path d={svgPaths.p23306380} fill="var(--fill-0, #087959)" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.500003" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[64.757px] items-start left-0 top-[4.62px] w-[73.993px]" data-name="Icon">
      <Icon />
    </div>
  );
}

function DeprecatedQsbIconButton() {
  return (
    <div className="absolute left-0 rounded-[4px] size-[73.993px] top-[47px]" data-name="DeprecatedQsbIconButton">
      <Icon1 />
    </div>
  );
}

function Container() {
  return <div className="absolute border-[1.111px] border-solid border-white h-[40px] left-0 rounded-[4px] top-0 w-[185.99px]" data-name="Container" />;
}

function Icon2() {
  return (
    <div className="h-[2.014px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0174 2.01389">
        <path d={svgPaths.pa591800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2.014px] items-start left-[5.99px] top-[7.99px] w-[20.017px]" data-name="Container">
      <Icon2 />
    </div>
  );
}

function Icon3() {
  return (
    <div className="h-[16.042px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.02778 16.0417">
        <path d={svgPaths.p1910f8c0} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Container2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[16.042px] items-start left-[3.99px] top-[0.99px] w-[9.028px]" data-name="Container">
      <Icon3 />
    </div>
  );
}

function Container3() {
  return (
    <div className="absolute h-[17.986px] left-[16.88px] top-[11.01px] w-[31.997px]" data-name="Container">
      <Container1 />
      <Container2 />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[26.667px] relative shrink-0 w-[112.257px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="css-ew64yg font-['Nunito_Sans:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[20px] text-white" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
          Back to RA+
        </p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute content-stretch flex flex-col h-[26.667px] items-start justify-center left-[56.86px] overflow-clip top-[6.67px] w-[112.257px]" data-name="Container">
      <Paragraph />
    </div>
  );
}

function QsbButton() {
  return (
    <div className="absolute bg-[#087959] h-[40px] left-0 rounded-[4px] top-0 w-[185.99px]" data-name="QsbButton">
      <Container />
      <Container3 />
      <Container4 />
    </div>
  );
}

function Container5() {
  return <div className="absolute border-[1.111px] border-solid border-white h-[40px] left-0 rounded-[4px] top-0 w-[212.986px]" data-name="Container" />;
}

function ChevronDown() {
  return <div className="h-[20.99px] w-[21.997px]" data-name="ChevronDown" />;
}

function Paragraph1() {
  return (
    <div className="h-[26.667px] relative shrink-0 w-[112.049px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="css-ew64yg font-['Nunito_Sans:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[20px] text-white" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
          English (US)
        </p>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute content-stretch flex flex-col h-[26.667px] items-start justify-center left-[52.59px] overflow-clip top-[6.67px] w-[112.049px]" data-name="Container">
      <Paragraph1 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute content-stretch flex h-[24.444px] items-start left-[172.62px] top-[7.78px] w-[15.764px]" data-name="Paragraph">
      <p className="css-ew64yg font-['Arimo:Regular','Noto_Sans:Regular',sans-serif] font-normal leading-[normal] relative shrink-0 text-[21px] text-center text-white"></p>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[181.04px] size-[20px] top-[11.01px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d="M5 7.5L10 12.5L15 7.5" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function QsbButton1() {
  return (
    <div className="absolute bg-[#087959] h-[40px] left-[206.99px] rounded-[4px] top-0 w-[212.986px]" data-name="QsbButton1">
      <Container5 />
      <div className="absolute flex h-[21.997px] items-center justify-center left-[1.74px] top-[10.13px] w-[20.99px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronDown />
        </div>
      </div>
      <Container6 />
      <Paragraph2 />
      <Icon4 />
    </div>
  );
}

function ActionsGroup() {
  return (
    <div className="absolute h-[40px] left-[33px] top-[40px] w-[420px]" data-name="ActionsGroup">
      <QsbButton />
      <QsbButton1 />
    </div>
  );
}

function Container7() {
  return (
    <div className="h-[7.986px] relative rounded-[999px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f5f8fa] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[999px]" />
    </div>
  );
}

function QsbBadgeIndicator() {
  return (
    <div className="absolute bg-[#cc1300] content-stretch flex flex-col items-start left-[23.02px] rounded-[999px] size-[7.986px] top-[10.99px]" data-name="QsbBadgeIndicator">
      <Container7 />
    </div>
  );
}

function AlertsContainer() {
  return (
    <div className="absolute left-0 size-[40px] top-0" data-name="AlertsContainer">
      <QsbBadgeIndicator />
    </div>
  );
}

function Icon5() {
  return (
    <div className="h-[41.979px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[1.19%]">
        <div className="absolute inset-[-1.22%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 41.9792 41.9792">
            <path d={svgPaths.p559d700} fill="var(--fill-0, #676F73)" id="Ellipse 1" stroke="var(--stroke-0, white)" strokeWidth="0.999504" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[-0.99px] size-[41.979px] top-[-0.99px]" data-name="Container">
      <Icon5 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="absolute h-[20px] left-0 top-[10px] w-[40px]" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['Nunito_Sans:Bold',sans-serif] font-bold leading-[20px] left-[20.49px] text-[18px] text-center text-white top-[-0.22px] translate-x-[-50%]" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
        MA
      </p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p31962400} id="Vector" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p1f3d9f80} id="Vector_2" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[#f5f8fa] content-stretch flex items-center justify-center left-0 rounded-[4px] size-[40px] top-0" data-name="Button">
      <Icon6 />
    </div>
  );
}

function Container9() {
  return <div className="absolute bg-[#cc1300] border-[#f5f8fa] border-[1.111px] border-solid left-[24.03px] rounded-[37282700px] size-[7.986px] top-[10px]" data-name="Container" />;
}

function Container10() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Button />
        <Container9 />
      </div>
    </div>
  );
}

function DeprecatedQsbIconButton1() {
  return (
    <div className="absolute bg-[#f5f8fa] content-stretch flex items-center justify-center left-[-48.94px] pl-[4.931px] pr-0 py-0 rounded-[4px] size-[40px] top-[0.01px]" data-name="DeprecatedQsbIconButton1">
      <Container10 />
    </div>
  );
}

function QsbAvatarImage() {
  return (
    <div className="absolute left-[47.99px] rounded-[999px] size-[40px] top-0" data-name="QsbAvatarImage">
      <Container8 />
      <Paragraph3 />
      <DeprecatedQsbIconButton1 />
    </div>
  );
}

function Overflow() {
  return (
    <div className="absolute h-[40px] left-[460.97px] top-[40px] w-[87.986px]" data-name="Overflow">
      <AlertsContainer />
      <QsbAvatarImage />
    </div>
  );
}

function End() {
  return (
    <div className="absolute h-[120px] left-[1256.01px] overflow-clip top-[24px] w-[559px]" data-name="End">
      <ActionsGroup />
      <Overflow />
    </div>
  );
}

function AppBarContainer() {
  return (
    <div className="absolute h-[143.993px] left-[22.99px] top-[-1px] w-[1815px]" data-name="AppBarContainer">
      <DeprecatedQsbIconButton />
      <End />
    </div>
  );
}

function Margin() {
  return <div className="absolute h-[2223.993px] left-0 top-0 w-[55.99px]" data-name="Margin" />;
}

function Image() {
  return (
    <div className="absolute h-[380.99px] left-0 top-0 w-[1760px]" data-name="Image">
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage} />
    </div>
  );
}

function Vision() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Vision">
      <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[32px_32px]" data-name="Vector" style={{ maskImage: `url('${imgVector}')` }}>
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
          <path d={svgPaths.p28dd1f00} fill="var(--fill-0, #090B0C)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision />
    </div>
  );
}

function Share() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
        <path d={svgPaths.p238ccd00} fill="var(--fill-0, #EFF3F9)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup />
    </div>
  );
}

function Icon7() {
  return (
    <div className="h-[60px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <Share />
    </div>
  );
}

function Share4() {
  return (
    <div className="absolute bg-[#087959] content-stretch flex flex-col items-start left-[14px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[70px] top-[111px]" data-name="Share4">
      <Icon7 />
    </div>
  );
}

function QsbTableCell() {
  return (
    <div className="absolute bg-[#087959] h-[55.99px] left-[98.99px] top-[143.01px] w-[531.997px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[66px] justify-center leading-[0] left-[-75.99px] text-[50px] text-white top-[-87.01px] translate-y-[-50%] w-[385px]">
        <p className="css-4hzbpn decoration-solid leading-[28px] underline">Popular Topics</p>
      </div>
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="absolute h-[28.003px] left-0 overflow-clip top-[10px] w-[516.024px]" data-name="Paragraph">
      <p className="absolute css-ew64yg font-['Nunito:Regular',sans-serif] font-normal leading-[28px] left-0 text-[32px] text-white top-[-0.56px]">Introduction to SERA AI Assistant</p>
    </div>
  );
}

function QsbTableCellText() {
  return (
    <div className="absolute h-[48px] left-[107px] overflow-clip top-[119px] w-[547px]" data-name="QsbTableCellText8">
      <Paragraph4 />
    </div>
  );
}

function UpRightFromSquare() {
  return (
    <div className="absolute contents inset-0" data-name="up-right-from-square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <path d={svgPaths.p1e5dc800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[30px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <UpRightFromSquare />
    </div>
  );
}

function UpRightFromSquare4() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[12.99px] size-[30px] top-[4.5px]" data-name="UpRightFromSquare4">
      <Icon8 />
    </div>
  );
}

function QsbTableCellText1() {
  return (
    <div className="absolute h-[38.993px] left-0 overflow-clip top-[8.49px] w-[55.99px]" data-name="QsbTableCellText9">
      <UpRightFromSquare4 />
    </div>
  );
}

function QsbTableCell1() {
  return (
    <div className="absolute bg-[#087959] left-[717px] size-[55.99px] top-[118px]" data-name="QsbTableCell14">
      <QsbTableCellText1 />
    </div>
  );
}

function UpRightFromSquare1() {
  return (
    <div className="absolute contents inset-0" data-name="up-right-from-square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <path d={svgPaths.p1e5dc800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Icon9() {
  return (
    <div className="h-[30px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <UpRightFromSquare1 />
    </div>
  );
}

function UpRightFromSquare5() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[12.99px] size-[30px] top-[4.5px]" data-name="UpRightFromSquare5">
      <Icon9 />
    </div>
  );
}

function QsbTableCellText2() {
  return (
    <div className="absolute h-[38.993px] left-0 overflow-clip top-[8.49px] w-[55.99px]" data-name="QsbTableCellText10">
      <UpRightFromSquare5 />
    </div>
  );
}

function QsbTableCell2() {
  return (
    <div className="absolute bg-[#087959] left-[717px] size-[55.99px] top-[209px]" data-name="QsbTableCell15">
      <QsbTableCellText2 />
    </div>
  );
}

function UpRightFromSquare2() {
  return (
    <div className="absolute contents inset-0" data-name="up-right-from-square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <path d={svgPaths.p1e5dc800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Icon10() {
  return (
    <div className="h-[30px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <UpRightFromSquare2 />
    </div>
  );
}

function UpRightFromSquare6() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[12.99px] size-[30px] top-[4.5px]" data-name="UpRightFromSquare6">
      <Icon10 />
    </div>
  );
}

function QsbTableCellText3() {
  return (
    <div className="absolute h-[38.993px] left-0 overflow-clip top-[8.49px] w-[55.99px]" data-name="QsbTableCellText11">
      <UpRightFromSquare6 />
    </div>
  );
}

function QsbTableCell3() {
  return (
    <div className="absolute bg-[#087959] left-[717px] size-[55.99px] top-[291px]" data-name="QsbTableCell16">
      <QsbTableCellText3 />
    </div>
  );
}

function UpRightFromSquare3() {
  return (
    <div className="absolute contents inset-0" data-name="up-right-from-square">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <path d={svgPaths.p1e5dc800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Icon11() {
  return (
    <div className="h-[30px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <UpRightFromSquare3 />
    </div>
  );
}

function UpRightFromSquare7() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[12.99px] size-[30px] top-[4.5px]" data-name="UpRightFromSquare7">
      <Icon11 />
    </div>
  );
}

function QsbTableCellText4() {
  return (
    <div className="absolute h-[38.993px] left-0 overflow-clip top-[8.49px] w-[55.99px]" data-name="QsbTableCellText12">
      <UpRightFromSquare7 />
    </div>
  );
}

function QsbTableCell4() {
  return (
    <div className="absolute bg-[#087959] left-[717px] size-[55.99px] top-[382px]" data-name="QsbTableCell17">
      <QsbTableCellText4 />
    </div>
  );
}

function MdiCompassOutline() {
  return (
    <div className="absolute contents inset-[27.78%]" data-name="mdi:compass-outline">
      <div className="absolute inset-[27.78%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26.6666 26.6666">
          <path d={svgPaths.p30fb9600} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Share1() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
        <path d={svgPaths.p238ccd00} fill="var(--fill-0, #EFF3F9)" id="Ellipse 7009" />
      </svg>
      <MdiCompassOutline />
    </div>
  );
}

function Icon12() {
  return (
    <div className="h-[60px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <Share1 />
    </div>
  );
}

function Share5() {
  return (
    <div className="absolute bg-[#087959] content-stretch flex flex-col items-start left-[16px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[70px] top-[200px]" data-name="Share5">
      <Icon12 />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="absolute h-[28px] left-0 overflow-clip top-[10px] w-[564px]" data-name="Paragraph">
      <p className="absolute css-g0mm18 font-['Nunito:Regular',sans-serif] font-normal leading-[28px] left-[0.01px] overflow-hidden text-[32px] text-ellipsis text-white top-[-0.99px] w-[564px]">Foundation of Sustainability and ESG</p>
    </div>
  );
}

function QsbTableCellText5() {
  return (
    <div className="absolute h-[48px] left-[8px] overflow-clip top-[4px] w-[564px]" data-name="QsbTableCellText13">
      <Paragraph5 />
    </div>
  );
}

function QsbTableCell6() {
  return (
    <div className="absolute bg-[#087959] h-[56px] left-[99px] top-[207px] w-[572px]" data-name="QsbTableCell19">
      <QsbTableCellText5 />
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-[7.99px] size-[60px] top-[7px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
        <g clipPath="url(#clip0_1_680)" id="Icon">
          <path d={svgPaths.p238ccd00} fill="var(--fill-0, #EFF3F9)" id="Ellipse 7009" />
        </g>
        <defs>
          <clipPath id="clip0_1_680">
            <rect fill="white" height="60" width="60" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents inset-[2.4%_3.08%]" data-name="Group">
      <div className="absolute inset-[35.35%_3.08%_2.4%_3.08%]" data-name="Vector">
        <div className="absolute inset-[-3.86%_-3.28%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.3749 20.942">
            <path d={svgPaths.pc574fa0} id="Vector" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_49.99%_46.34%_50.01%]" data-name="Vector_2">
        <div className="absolute inset-[-4.69%_-0.75px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.50103 17.5112">
            <path d="M0.750515 16.7607V0.750515" id="Vector_2" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_31.23%_82.95%_31.23%]" data-name="Vector_3">
        <div className="absolute inset-[-16.41%_-8.2%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.6506 6.07537">
            <path d={svgPaths.p1ba5e4c8} id="Vector_3" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon14() {
  return (
    <div className="h-[31.233px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <Group />
    </div>
  );
}

function Group2() {
  return (
    <div className="content-stretch flex flex-col h-[31.233px] items-start relative shrink-0 w-full" data-name="Group2">
      <Icon14 />
    </div>
  );
}

function ShareIcon() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[21.99px] overflow-clip pb-0 pl-[3.819px] pr-[3.802px] pt-[0.382px] size-[31.997px] top-[21px]" data-name="ShareIcon2">
      <Group2 />
    </div>
  );
}

function Share6() {
  return (
    <div className="absolute bg-[#087959] left-[17px] size-[70px] top-[284px]" data-name="Share6">
      <Icon13 />
      <ShareIcon />
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="absolute h-[56.007px] left-0 overflow-clip top-[-3.99px] w-[532.014px]" data-name="Paragraph">
      <p className="absolute css-g0mm18 font-['Nunito:Regular',sans-serif] font-normal leading-[28px] left-0 overflow-hidden text-[32px] text-ellipsis text-white top-[13.99px] w-[532px]">Quick start guide to Upload Data for Visualizations</p>
    </div>
  );
}

function QsbTableCellText6() {
  return (
    <div className="absolute h-[48px] left-[16px] overflow-clip top-0 w-[532px]" data-name="QsbTableCellText14">
      <Paragraph6 />
    </div>
  );
}

function QsbTableCell8() {
  return (
    <div className="absolute bg-[#087959] h-[56px] left-[91px] top-[298px] w-[580px]" data-name="QsbTableCell21">
      <QsbTableCellText6 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-[2.4%_3.08%]" data-name="Group">
      <div className="absolute inset-[35.35%_3.08%_2.4%_3.08%]" data-name="Vector">
        <div className="absolute inset-[-3.86%_-3.28%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.3749 20.942">
            <path d={svgPaths.pc574fa0} id="Vector" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_49.99%_46.34%_50.01%]" data-name="Vector_2">
        <div className="absolute inset-[-4.69%_-0.75px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.50103 17.5112">
            <path d="M0.750515 16.7607V0.750515" id="Vector_2" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_31.23%_82.95%_31.23%]" data-name="Vector_3">
        <div className="absolute inset-[-16.41%_-8.2%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.6506 6.07537">
            <path d={svgPaths.p1ba5e4c8} id="Vector_3" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon15() {
  return (
    <div className="h-[31.233px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <Group1 />
    </div>
  );
}

function Group3() {
  return (
    <div className="content-stretch flex flex-col h-[31.233px] items-start relative shrink-0 w-full" data-name="Group3">
      <Icon15 />
    </div>
  );
}

function ShareIcon1() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip pb-0 pl-[3.802px] pr-[3.819px] pt-[0.382px] relative size-full" data-name="ShareIcon3">
      <Group3 />
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-[7.99px] overflow-clip size-[60px] top-[7px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
        <path d={svgPaths.p238ccd00} fill="var(--fill-0, #EFF3F9)" id="Ellipse 7009" />
      </svg>
      <div className="absolute flex inset-[23.37%_23.26%_23.3%_23.41%] items-center justify-center">
        <div className="flex-none rotate-[180deg] size-[31.997px]">
          <ShareIcon1 />
        </div>
      </div>
    </div>
  );
}

function Share7() {
  return (
    <div className="absolute bg-[#087959] left-[17px] size-[70px] top-[373px]" data-name="Share7">
      <Icon16 />
    </div>
  );
}

function Paragraph7() {
  return (
    <div className="absolute h-[56.007px] left-0 overflow-clip top-[-3.99px] w-[532.014px]" data-name="Paragraph">
      <p className="absolute css-g0mm18 font-['Nunito:Regular',sans-serif] font-normal leading-[28px] left-[0.01px] overflow-hidden text-[32px] text-ellipsis text-white top-[9px] w-[548px]">Quick start guide to Download Data for Visualizations</p>
    </div>
  );
}

function QsbTableCellText7() {
  return (
    <div className="absolute h-[48.003px] left-[7.99px] overflow-clip top-[3.99px] w-[532.014px]" data-name="QsbTableCellText15">
      <Paragraph7 />
    </div>
  );
}

function QsbTableCell10() {
  return (
    <div className="absolute bg-[#087959] h-[55.99px] left-[99px] top-[387px] w-[547.986px]" data-name="QsbTableCell23">
      <QsbTableCellText7 />
    </div>
  );
}

function QdsDropdown() {
  return (
    <div className="absolute bg-[#087959] h-[510px] left-[891px] rounded-[4px] top-[47px] w-[847px]" data-name="QdsDropdown1">
      <Share4 />
      <QsbTableCell />
      <QsbTableCellText />
      <QsbTableCell1 />
      <QsbTableCell2 />
      <QsbTableCell3 />
      <QsbTableCell4 />
      <Share5 />
      <QsbTableCell6 />
      <Share6 />
      <QsbTableCell8 />
      <Share7 />
      <QsbTableCell10 />
    </div>
  );
}

function Step() {
  return (
    <div className="absolute h-[20px] left-0 overflow-clip top-[5.99px] w-[78.993px]" data-name="Step">
      <p className="absolute css-ew64yg decoration-solid font-['Nunito:Regular',sans-serif] font-normal leading-[20px] left-0 text-[#090b0c] text-[16px] top-[-0.11px] underline">Homepage</p>
    </div>
  );
}

function Paragraph8() {
  return (
    <div className="h-[90px] relative shrink-0 w-[880px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-4hzbpn font-['Nunito:Bold',sans-serif] font-bold h-[109px] leading-[90px] left-[0.02px] text-[85px] text-black top-[0.52px] w-[872px]">Looking for answers?</p>
      </div>
    </div>
  );
}

function Paragraph9() {
  return (
    <div className="h-[107px] relative shrink-0 w-[880px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['Nunito:Bold',sans-serif] font-bold leading-[90px] left-0 text-[85px] text-black top-0">We’re here for you</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="absolute content-stretch flex flex-col h-[253.993px] items-start justify-center left-[0.02px] top-[47.01px] w-[880px]" data-name="Container">
      <Paragraph8 />
      <Paragraph9 />
    </div>
  );
}

function Container12() {
  return <div className="absolute border-[#676f73] border-[1.111px] border-solid h-[74px] left-0 rounded-[4px] top-0 w-[839px]" data-name="Container" />;
}

function Paragraph10() {
  return (
    <div className="h-[38px] relative shrink-0 w-[604px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="css-4hzbpn flex-[1_0_0] font-['Nunito_Sans:Regular',sans-serif] font-normal h-[38px] leading-[normal] min-h-px min-w-px relative text-[#676f73] text-[28px]" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
          Search
        </p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute content-stretch flex flex-col h-[43px] items-start justify-center left-[31px] overflow-clip top-[15px] w-[604px]" data-name="Container">
      <Paragraph10 />
    </div>
  );
}

function Icon17() {
  return (
    <div className="h-[2.014px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0174 2.01389">
        <path d={svgPaths.pa591800} fill="var(--fill-0, #087959)" id="Vector" />
      </svg>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2.014px] items-start left-[5.99px] top-[7.99px] w-[20.017px]" data-name="Container">
      <Icon17 />
    </div>
  );
}

function Icon18() {
  return (
    <div className="h-[16.042px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.02778 16.0417">
        <path d={svgPaths.p1910f8c0} fill="var(--fill-0, #087959)" id="Vector" />
      </svg>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute content-stretch flex flex-col h-[16.042px] items-start left-[3.99px] top-[0.99px] w-[9.028px]" data-name="Container">
      <Icon18 />
    </div>
  );
}

function Container16() {
  return (
    <div className="relative size-full" data-name="Container">
      <Container14 />
      <Container15 />
    </div>
  );
}

function Icon19() {
  return (
    <div className="absolute left-[772px] overflow-clip size-[60px] top-[7px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 60 60">
        <path d={svgPaths.p238ccd00} fill="var(--fill-0, #EFF3F9)" id="Ellipse 7009" />
      </svg>
      <div className="absolute flex inset-[35%_26.67%_35.02%_20%] items-center justify-center">
        <div className="flex-none h-[17.986px] rotate-[180deg] w-[31.997px]">
          <Container16 />
        </div>
      </div>
    </div>
  );
}

function Search() {
  return (
    <div className="absolute bg-white h-[74px] left-[0.02px] rounded-[4px] top-[294.01px] w-[839px]" data-name="Search">
      <Container12 />
      <Container13 />
      <Icon19 />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[380.99px] left-0 top-0 w-[880px]" data-name="Frame">
      <Step />
      <Container11 />
      <Search />
    </div>
  );
}

function Paragraph11() {
  return (
    <div className="h-[29.983px] relative shrink-0 w-[456.059px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute css-ew64yg font-['Arimo:Regular',sans-serif] font-normal leading-[0] left-0 text-[36px] text-black top-[-2.11px]">
          <span className="leading-[30px]">{`Keywords: `}</span>
          <span className="[text-decoration-skip-ink:none] decoration-solid leading-[30px] underline">SERA</span>
          <span className="leading-[30px]">{`, `}</span>
          <span className="[text-decoration-skip-ink:none] decoration-solid leading-[30px] underline">Product Tutorial</span>
          <span className="leading-[30px]">{`, `}</span>
          <span className="[text-decoration-skip-ink:none] decoration-solid leading-[30px] underline">Upload Data</span>
        </p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#f2f4f4] content-stretch flex h-[92px] items-center left-[-13px] pl-[15.99px] pr-0 py-0 rounded-[4px] top-[370px] w-[852px]" data-name="Button">
      <Paragraph11 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute h-[557px] left-[0.02px] top-[0.01px] w-[1760px]" data-name="Group5">
      <Image />
      <QdsDropdown />
      <Frame />
      <Button1 />
    </div>
  );
}

function Vision1() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup1() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision1 />
    </div>
  );
}

function Share2() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup1 />
    </div>
  );
}

function Icon20() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share2 />
    </div>
  );
}

function Share8() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon20 />
    </div>
  );
}

function QsbTableCell5() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[164px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[276px]">
        <p className="css-4hzbpn leading-[50px]">Home and Navigation</p>
      </div>
    </div>
  );
}

function QdsDropdown1() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[0.02px] rounded-[4px] top-[1303.01px] w-[524px]" data-name="QdsDropdown1">
      <Share8 />
      <QsbTableCell5 />
    </div>
  );
}

function Vision2() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup2() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision2 />
    </div>
  );
}

function Share3() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup2 />
    </div>
  );
}

function Icon21() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share3 />
    </div>
  );
}

function Share9() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon21 />
    </div>
  );
}

function QsbTableCell7() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[160px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[442px]">
        <p className="css-4hzbpn leading-[50px]">Carbon Footprint and Emissions</p>
      </div>
    </div>
  );
}

function QdsDropdown2() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[0.02px] rounded-[4px] top-[1743.01px] w-[524px]" data-name="QdsDropdown1">
      <Share9 />
      <QsbTableCell7 />
    </div>
  );
}

function Vision3() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup3() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision3 />
    </div>
  );
}

function Share10() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup3 />
    </div>
  );
}

function Icon22() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share10 />
    </div>
  );
}

function Share11() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon22 />
    </div>
  );
}

function QsbTableCell9() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[171px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[456px]">
        <p className="css-4hzbpn leading-[50px]">Supply Chain Management</p>
      </div>
    </div>
  );
}

function QdsDropdown3() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[607.02px] rounded-[4px] top-[1743.01px] w-[524px]" data-name="QdsDropdown1">
      <Share11 />
      <QsbTableCell9 />
    </div>
  );
}

function Vision4() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup4() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision4 />
    </div>
  );
}

function Share12() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup4 />
    </div>
  );
}

function Icon23() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share12 />
    </div>
  );
}

function Share13() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon23 />
    </div>
  );
}

function QsbTableCell11() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[179px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[358px]">
        <p className="css-4hzbpn leading-[50px]">Sustainability and ESG</p>
      </div>
    </div>
  );
}

function QdsDropdown4() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[1215.02px] rounded-[4px] top-[1743.01px] w-[524px]" data-name="QdsDropdown1">
      <Share13 />
      <QsbTableCell11 />
    </div>
  );
}

function Vision5() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup5() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision5 />
    </div>
  );
}

function Share14() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup5 />
    </div>
  );
}

function Icon24() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share14 />
    </div>
  );
}

function Share15() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon24 />
    </div>
  );
}

function QsbTableCell12() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[164px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[276px]">
        <p className="css-4hzbpn leading-[50px]">SERA</p>
      </div>
    </div>
  );
}

function QdsDropdown5() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[607.02px] rounded-[4px] top-[1303.01px] w-[524px]" data-name="QdsDropdown1">
      <Share15 />
      <QsbTableCell12 />
    </div>
  );
}

function Vision6() {
  return (
    <div className="absolute inset-[22.22%_22.22%_24.44%_24.44%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[80px_80px]" data-name="Vision" style={{ maskImage: `url('${imgVision}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g id="Vision">
          <path d={svgPaths.p768e080} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup6() {
  return (
    <div className="absolute contents inset-[22.22%_22.22%_24.44%_24.44%]" data-name="Clip path group">
      <Vision6 />
    </div>
  );
}

function Share16() {
  return (
    <div className="absolute contents inset-0" data-name=".share">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 150">
        <path d={svgPaths.p2bd5f000} fill="var(--fill-0, #087959)" id="Ellipse 7009" />
      </svg>
      <ClipPathGroup6 />
    </div>
  );
}

function Icon25() {
  return (
    <div className="overflow-clip relative shrink-0 size-[150px]" data-name="Icon">
      <Share16 />
    </div>
  );
}

function Share17() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[186px] pb-0 pl-[7.986px] pr-[2.014px] pt-[6.997px] size-[150px] top-[24px]" data-name="Share4">
      <Icon25 />
    </div>
  );
}

function QsbTableCell13() {
  return (
    <div className="absolute h-[38px] left-[98px] top-[191px] w-[425px]" data-name="QsbTableCell13">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[95px] justify-center leading-[0] left-[162px] text-[#087959] text-[50px] text-center top-[66.5px] translate-x-[-50%] translate-y-[-50%] w-[386px]">
        <p className="css-4hzbpn leading-[50px]">Dashboard and Analytics</p>
      </div>
    </div>
  );
}

function QdsDropdown6() {
  return (
    <div className="absolute bg-white border border-[#d4d8d9] border-solid h-[350px] left-[1214.02px] rounded-[4px] top-[1303.01px] w-[524px]" data-name="QdsDropdown1">
      <Share17 />
      <QsbTableCell13 />
    </div>
  );
}

function QdsDropdown7() {
  return (
    <div className="absolute bg-white h-[552px] leading-[0] left-[839px] rounded-[4px] text-black top-[-1px] w-[898px]" data-name="QdsDropdown1">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[180px] justify-center left-[18px] text-[52px] top-[125px] translate-y-[-50%] w-[880px]">
        <p className="css-4hzbpn leading-[80px]">Welcome to the Resource Advisor+ Knowledge Hub</p>
      </div>
      <div className="absolute flex flex-col font-['Nunito:Regular',sans-serif] font-normal h-[235px] justify-center left-[18px] text-[32px] top-[354.5px] translate-y-[-50%] w-[880px]">
        <p className="css-4hzbpn leading-[40px]">{`Our mission is to simplify Sustainability and Decarbonization topics for you! We've put in a lot of effort to ensure Resource Advisor+ is as user-friendly as possible, but we understand you might still have questions. The good news? Real people are here behind the scenes, ready to assist you. Take your time exploring our Knowledge Hub, and if you you need any further assistance, don't hesitate to reach out.`}</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute border border-[#d4d8d9] border-solid h-[552px] left-[0.02px] rounded-[4px] top-[590.01px] w-[1738px]" data-name="Container">
      <QdsDropdown7 />
      <div className="absolute h-[552px] left-[-1px] rounded-[4px] top-[-1px] w-[840px]" data-name="image 7">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[4px] size-full" src={imgImage7} />
      </div>
    </div>
  );
}

function Main() {
  return (
    <div className="absolute h-[2223.993px] left-[55.99px] overflow-clip top-0 w-[1760.035px]" data-name="Main">
      <Group4 />
      <QdsDropdown1 />
      <QdsDropdown2 />
      <QdsDropdown3 />
      <QdsDropdown4 />
      <QdsDropdown5 />
      <QdsDropdown6 />
      <Container17 />
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[180px] justify-center leading-[0] left-[3.02px] text-[52px] text-black top-[1232.01px] translate-y-[-50%] w-[880px]">
        <p className="css-4hzbpn leading-[80px]">Topics</p>
      </div>
    </div>
  );
}

function Icon26() {
  return (
    <div className="h-[2.014px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.0174 2.01389">
        <path d={svgPaths.pa591800} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2.014px] items-start left-[5.99px] top-[7.99px] w-[20.017px]" data-name="Container">
      <Icon26 />
    </div>
  );
}

function Icon27() {
  return (
    <div className="h-[16.042px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.02778 16.0417">
        <path d={svgPaths.p1910f8c0} fill="var(--fill-0, white)" id="Vector" />
      </svg>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex flex-col h-[16.042px] items-start left-[3.99px] top-[0.99px] w-[9.028px]" data-name="Container">
      <Icon27 />
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[17.986px] relative w-[31.997px]" data-name="Container">
      <Container18 />
      <Container19 />
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute border-[1.111px] border-solid border-white h-[46px] left-0 rounded-[4px] top-0 w-[186px]" data-name="Container">
      <div className="absolute flex h-[17.986px] items-center justify-center left-[140.89px] top-[12.89px] w-[31.997px]">
        <div className="flex-none rotate-[180deg]">
          <Container20 />
        </div>
      </div>
    </div>
  );
}

function Paragraph12() {
  return (
    <div className="h-[26.667px] relative shrink-0 w-[112.257px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="css-4hzbpn font-['Nunito_Sans:Medium',sans-serif] font-medium leading-[normal] relative shrink-0 text-[20px] text-white w-[115px]" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
          Contact Us!
        </p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex flex-col h-[27px] items-start justify-center left-[21px] overflow-clip top-[9px] w-[113px]" data-name="Container">
      <Paragraph12 />
    </div>
  );
}

function QsbButton2() {
  return (
    <div className="absolute bg-[#087959] h-[46px] left-[557px] rounded-[4px] top-[171px] w-[186px]" data-name="QsbButton">
      <Container21 />
      <Container22 />
    </div>
  );
}

function QdsDropdown8() {
  return (
    <div className="absolute bg-white h-[552px] left-[904px] rounded-[4px] top-[-1px] w-[833px]" data-name="QdsDropdown1">
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[79px] justify-center leading-[0] left-[18px] text-[52px] text-black top-[74.5px] translate-y-[-50%] w-[815px]">
        <p className="css-4hzbpn leading-[80px]">Contact Support</p>
      </div>
      <div className="absolute flex flex-col font-['Nunito:Bold',sans-serif] font-bold h-[79px] justify-center leading-[0] left-[18px] text-[52px] text-black top-[347.5px] translate-y-[-50%] w-[815px]">
        <p className="css-4hzbpn leading-[80px]">Follow us on Social Media</p>
      </div>
      <div className="absolute flex flex-col font-['Nunito:Regular',sans-serif] font-normal h-[203px] justify-center leading-[0] left-[18px] text-[32px] text-black top-[206.5px] translate-y-[-50%] w-[505px]">
        <p className="css-4hzbpn leading-[40px]">Ideally, contact us directly from Resource Advisor+. Alternatively, our team of experts can assist you via our contact forms!</p>
      </div>
      <QsbButton2 />
      <div className="absolute left-[85px] size-[100px] top-[403px]" data-name="ic:baseline-facebook">
        <div className="absolute inset-[8.33%_8.33%_8.54%_8.33%]" data-name="Vector">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 83.3333 83.125">
            <path d={svgPaths.p25597c80} fill="var(--fill-0, #087959)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[234px] size-[100px] top-[403px]" data-name="mdi:twitter">
        <div className="absolute inset-[16.67%_6.42%_12.5%_6.42%]" data-name="Vector">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 87.1667 70.8333">
            <path d={svgPaths.p3070b200} fill="var(--fill-0, #087959)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[384px] size-[100px] top-[403px]" data-name="mdi:instagram">
        <div className="absolute inset-[8.33%]" data-name="Vector">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 83.3333 83.3333">
            <path d={svgPaths.p9aaa540} fill="var(--fill-0, #087959)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[533px] size-[100px] top-[403px]" data-name="mdi:linkedin">
        <div className="absolute inset-[12.5%]" data-name="Vector">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 75 75">
            <path d={svgPaths.p24147000} fill="var(--fill-0, #087959)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute border border-[#d4d8d9] border-solid h-[552px] left-[56px] rounded-[4px] top-[2167px] w-[1738px]" data-name="Container">
      <div className="absolute h-[553px] left-[-1px] top-[-1px] w-[968px]" data-name="image 11">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage11} />
      </div>
      <QdsDropdown8 />
    </div>
  );
}

function Margin1() {
  return <div className="absolute h-[2223.993px] left-[1816.02px] top-0 w-[55.99px]" data-name="Margin1" />;
}

function Cta() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="CTA">
      <div className="css-g0mm18 flex flex-col font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#090b0c] text-[12px]">
        <p className="css-ew64yg leading-[1.4]">Privacy Policy</p>
      </div>
      <div className="flex h-[10px] items-center justify-center relative shrink-0 w-0" style={{ "--transform-inner-width": "300", "--transform-inner-height": "150" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[10px]">
            <div className="absolute inset-[-1px_0_0_0]" style={{ "--stroke-0": "rgba(160, 162, 167, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 1">
                <line id="Line 50" stroke="var(--stroke-0, #A0A2A7)" x2="10" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="css-g0mm18 flex flex-col font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#090b0c] text-[12px]">
        <p className="css-ew64yg leading-[1.4]">Terms of Use</p>
      </div>
    </div>
  );
}

function Cta1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="CTA">
      <Cta />
    </div>
  );
}

function Footer() {
  return (
    <div className="absolute bg-[#fefefe] content-stretch flex items-center justify-between left-0 overflow-clip px-[24px] py-[12px] top-[2773px] w-[1872px]" data-name="Footer">
      <div className="css-g0mm18 flex flex-col font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#090b0c] text-[16px]">
        <p className="css-ew64yg leading-[1.4]">© 2026 Schneider Electric Industries SAS. All Rights Reserved.</p>
      </div>
      <Cta1 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute bg-[#f2f4f4] h-[2837px] left-[23px] overflow-clip top-[143px] w-[1872px]" data-name="MainContent">
      <Margin />
      <Main />
      <Container23 />
      <Margin1 />
      <Footer />
    </div>
  );
}

function MainContentContainer() {
  return (
    <div className="absolute bg-[#f4f6f8] border border-black border-solid h-[2963px] left-0 overflow-clip top-0 w-[1920px]" data-name="MainContentContainer">
      <AppBarContainer />
      <MainContent />
    </div>
  );
}

function QsbPageTemplateMain() {
  return (
    <div className="absolute bg-[#f4f7f9] h-[2963px] left-[-1px] overflow-clip top-[-1px] w-[1920px]" data-name="QsbPageTemplateMain">
      <MainContentContainer />
    </div>
  );
}

function TitleContainer() {
  return (
    <div className="absolute h-[43.993px] left-[121px] top-[57.99px] w-[1130px]" data-name="TitleContainer">
      <p className="absolute css-ew64yg font-['Nunito:Bold',sans-serif] font-bold leading-[44px] left-0 text-[#087959] text-[64px] top-[-0.22px]">Resource Advisor+ Knowledge Base</p>
    </div>
  );
}

export default function LandingPageV() {
  return (
    <div className="bg-[#f2f4f4] border border-black border-solid relative size-full" data-name="LANDING PAGE V1">
      <QsbPageTemplateMain />
      <TitleContainer />
    </div>
  );
}