import { Link } from "react-router-dom";
import svgPaths from "@/imports/svg-07n4l0j7g2";
import { useState, useRef, useEffect } from "react";
import { NotificationsButton } from "./NotificationsButton";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function Header() {
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const languageDropdownRef = useRef<HTMLDivElement>(null);
  const searchDropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Sustainability-related search suggestions
  const allSuggestions = [
    "Carbon Footprint",
    "Greenhouse Gas Emissions",
    "Renewable Energy",
    "ESG Reporting",
    "Supply Chain Sustainability",
    "Circular Economy",
    "Net Zero Goals",
    "Energy Efficiency",
    "Sustainable Procurement",
    "Climate Risk Assessment",
    "Waste Management",
    "Water Conservation",
    "Biodiversity",
    "Social Responsibility",
    "Green Building",
  ];

  const languageOptions = [
    { code: "en-US", label: "English (US)" },
    { code: "es-ES", label: "Español (Spanish)" },
    { code: "fr-FR", label: "Français (French)" },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (languageDropdownRef.current && !languageDropdownRef.current.contains(event.target as Node)) {
        setIsLanguageDropdownOpen(false);
      }
      if (searchDropdownRef.current && !searchDropdownRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setShowSuggestions(false);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    setShowSuggestions(value.length > 0);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    setShowSuggestions(false);
    navigate(`/search?q=${encodeURIComponent(suggestion)}`);
  };

  const handleViewMore = () => {
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    } else {
      navigate('/search');
    }
    setShowSuggestions(false);
  };

  // Filter suggestions based on search query
  const filteredSuggestions = searchQuery.trim()
    ? allSuggestions.filter(suggestion =>
        suggestion.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : allSuggestions.slice(0, 5);

  return (
    <div className="relative h-[143.993px] w-full flex items-center justify-between px-[40px]" data-name="AppBarContainer">
      <Link to="/" className="rounded-[4px] size-[73.993px] flex-shrink-0" data-name="DeprecatedQsbIconButton">
        <div className="w-[73.993px] h-[64.757px] flex items-center" data-name="Icon">
          <div className="h-[64.757px] overflow-clip relative shrink-0 w-full" data-name="Icon">
            <div className="absolute inset-[0.39%_0.34%]" data-name="Vector">
              <div className="absolute inset-[-0.39%_-0.34%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73.9904 64.7573">
                  <path d={svgPaths.p23306380} fill="var(--fill-0, #087959)" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.500003" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </Link>

      {/* Center Search Bar */}
      <div className="flex-1 max-w-[600px] mx-auto">
        <div className="relative" ref={searchDropdownRef}>
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              placeholder="Search"
              value={searchQuery}
              onChange={handleSearchChange}
              onFocus={() => searchQuery.length > 0 && setShowSuggestions(true)}
              className="w-full h-[64px] bg-white border border-[#676f73] border-solid rounded-[4px] px-[24px] pr-[70px] font-['Nunito_Sans:Regular',sans-serif] text-[24px] text-[#676f73] focus:outline-none focus:border-[#087959]"
            />
            <button 
              type="submit"
              className="absolute right-[5px] top-[5px] w-[54px] h-[54px] bg-[#087959] rounded-full flex items-center justify-center hover:bg-[#0a9570] transition-colors"
            >
              <Search className="w-[28px] h-[28px] text-white" />
            </button>
          </form>

          {/* Search Suggestions Dropdown */}
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute top-[68px] left-0 right-0 bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50 overflow-hidden">
              {filteredSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full text-left px-[24px] py-[12px] font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c] hover:bg-[#f0f9f7] transition-colors border-b border-[#e8eaeb] last:border-b-0"
                >
                  {suggestion}
                </button>
              ))}
              
              {/* View More Button */}
              <button
                onClick={handleViewMore}
                className="w-full px-[24px] py-[14px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[18px] text-[#087959] hover:bg-[#f0f9f7] transition-colors border-t-2 border-[#d4d8d9]"
              >
                View More →
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-[12px] flex-shrink-0" data-name="End">
        <button className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[200px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center px-[12px]">
          <div className="flex items-center gap-[8px]">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="flex-shrink-0">
              <path d="M15 10H5M5 10L10 15M5 10L10 5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="whitespace-nowrap">Back to RA+</span>
          </div>
        </button>

        <div ref={languageDropdownRef} className="relative" data-name="LanguageDropdown">
          <button
            className="bg-[#087959] border border-white border-solid rounded-[4px] h-[40px] w-[213px] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium text-[20px] flex items-center justify-center gap-[8px] px-[16px]"
            onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
          >
            <span>English (US)</span>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M5 7.5L10 12.5L15 7.5" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            </svg>
          </button>

          {isLanguageDropdownOpen && (
            <div className="absolute right-0 top-[44px] w-[213px] bg-white border border-[#d4d8d9] border-solid rounded-[4px] shadow-lg z-50">
              {languageOptions.map((option) => (
                <button
                  key={option.code}
                  className="w-full text-left px-[16px] py-[12px] font-['Nunito_Sans:Medium',sans-serif] font-medium text-[18px] text-[#090b0c] hover:bg-[#f0f9f7] first:rounded-t-[4px] last:rounded-b-[4px] transition-colors"
                  onClick={() => {
                    setIsLanguageDropdownOpen(false);
                  }}
                >
                  {option.label}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center gap-[8px]" data-name="Overflow">
          <div className="size-[40px]" data-name="AlertsContainer">
            <NotificationsButton />
          </div>

          <Link to="/profile" className="rounded-[999px] size-[40px] relative hover:opacity-80 transition-opacity cursor-pointer" data-name="QsbAvatarImage">
            <div className="absolute content-stretch flex flex-col items-start left-[-0.99px] size-[41.979px] top-[-0.99px]" data-name="Container">
              <div className="h-[41.979px] overflow-clip relative shrink-0 w-full" data-name="Icon">
                <div className="absolute inset-[1.19%]">
                  <div className="absolute inset-[-1.22%]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 41.9792 41.9792">
                      <path d={svgPaths.p559d700} fill="var(--fill-0, #676F73)" id="Ellipse 1" stroke="var(--stroke-0, white)" strokeWidth="0.999504" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute h-[20px] left-0 top-[10px] w-[40px]" data-name="Paragraph">
              <p className="absolute css-ew64yg font-['Nunito_Sans:Bold',sans-serif] font-bold leading-[20px] left-[20.49px] text-[18px] text-center text-white top-[-0.22px] translate-x-[-50%]" style={{ fontVariationSettings: "'YTLC' 500, 'wdth' 100" }}>
                MA
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}