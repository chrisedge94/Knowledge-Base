import { useParams, Link, useSearchParams } from "react-router-dom";
import svgPaths from "@/imports/svg-07n4l0j7g2";
import { Header } from "./Header";
import { ArrowLeft, BookOpen, FileText, Clock, ThumbsUp, ThumbsDown } from "lucide-react";
import { useEffect, useState } from "react";
import BackToKnowledgeBase from "@/imports/Link";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";

const articles = {
  "1": {
    title: "Introduction to SERA AI Assistant",
    category: "Getting Started",
    readTime: "5 min read",
    lastUpdated: "January 15, 2026",
    content: [
      {
        type: "intro",
        text: "The SERA AI Assistant is your intelligent companion for navigating sustainability and environmental reporting. This guide will help you understand how to leverage SERA's capabilities to streamline your workflow.",
      },
      {
        type: "section",
        heading: "What is SERA?",
        text: "SERA (Sustainability and Environmental Reporting Assistant) is an advanced AI-powered tool designed to help you analyze, report, and manage your environmental data. It uses natural language processing to understand your queries and provide accurate, contextual responses.",
      },
      {
        type: "section",
        heading: "Key Features",
        items: [
          "Natural language query processing",
          "Real-time data analysis and visualization",
          "Automated report generation",
          "Compliance checking and recommendations",
          "Integration with Resource Advisor+ ecosystem",
        ],
      },
      {
        type: "section",
        heading: "Getting Started",
        text: "To start using SERA, simply type your question in natural language. For example, you can ask:",
        items: [
          "\"What are my carbon emissions for Q4 2025?\"",
          "\"Show me energy consumption trends for the past 6 months\"",
          "\"Generate a sustainability report for my facilities\"",
        ],
      },
      {
        type: "tip",
        text: "Pro Tip: Be specific with your questions. Instead of asking 'Show me data,' try 'Show me electricity consumption for Building A in December 2025.'",
      },
      {
        type: "section",
        heading: "Best Practices",
        items: [
          "Start with simple queries to familiarize yourself with SERA's capabilities",
          "Use specific date ranges and location filters for more accurate results",
          "Save frequently used queries for quick access",
          "Review SERA's suggestions to improve your environmental performance",
        ],
      },
    ],
  },
  "2": {
    title: "Foundation of Sustainability and ESG",
    category: "ESG Fundamentals",
    readTime: "8 min read",
    lastUpdated: "January 18, 2026",
    content: [
      {
        type: "intro",
        text: "Understanding the fundamentals of Environmental, Social, and Governance (ESG) is crucial for modern businesses. This article covers the core concepts and why they matter.",
      },
      {
        type: "section",
        heading: "What is ESG?",
        text: "ESG stands for Environmental, Social, and Governance. These three factors are used to measure the sustainability and ethical impact of an investment in a company or business.",
      },
      {
        type: "section",
        heading: "The Three Pillars",
        subsections: [
          {
            heading: "Environmental (E)",
            text: "Focuses on a company's impact on the planet, including:",
            items: [
              "Carbon emissions and climate change",
              "Energy efficiency and renewable energy",
              "Waste management and recycling",
              "Water usage and conservation",
              "Biodiversity and land use",
            ],
          },
          {
            heading: "Social (S)",
            text: "Examines relationships with stakeholders:",
            items: [
              "Employee welfare and working conditions",
              "Diversity and inclusion",
              "Community engagement",
              "Customer satisfaction",
              "Human rights",
            ],
          },
          {
            heading: "Governance (G)",
            text: "Relates to company leadership and controls:",
            items: [
              "Board composition and structure",
              "Executive compensation",
              "Business ethics",
              "Transparency and reporting",
              "Stakeholder rights",
            ],
          },
        ],
      },
      {
        type: "section",
        heading: "Why ESG Matters",
        text: "ESG principles are increasingly important for:",
        items: [
          "Attracting and retaining investors",
          "Meeting regulatory requirements",
          "Managing risks and opportunities",
          "Building brand reputation",
          "Improving operational efficiency",
        ],
      },
      {
        type: "tip",
        text: "Important: ESG is not just about compliance—it's about creating long-term value for all stakeholders.",
      },
    ],
  },
  "3": {
    title: "Quick start guide to Upload Data for Visualizations",
    category: "Data Management",
    readTime: "6 min read",
    lastUpdated: "January 20, 2026",
    content: [
      {
        type: "intro",
        text: "Learn how to efficiently upload your data into Resource Advisor+ to create powerful visualizations and insights.",
      },
      {
        type: "section",
        heading: "Supported File Formats",
        text: "Resource Advisor+ accepts the following file formats:",
        items: [
          "CSV (Comma-Separated Values) - Recommended",
          "Excel (.xlsx, .xls)",
          "JSON (JavaScript Object Notation)",
          "XML (Extensible Markup Language)",
        ],
      },
      {
        type: "section",
        heading: "Step-by-Step Upload Process",
        subsections: [
          {
            heading: "Step 1: Prepare Your Data",
            items: [
              "Ensure your data is clean and properly formatted",
              "Include column headers in the first row",
              "Use consistent date formats (YYYY-MM-DD recommended)",
              "Remove any duplicate entries",
            ],
          },
          {
            heading: "Step 2: Navigate to Upload",
            items: [
              "Click on 'Data Management' in the main menu",
              "Select 'Upload Data' from the dropdown",
              "Choose your data category (Energy, Emissions, Water, etc.)",
            ],
          },
          {
            heading: "Step 3: Upload and Map Fields",
            items: [
              "Click 'Choose File' and select your prepared file",
              "Map your data columns to Resource Advisor+ fields",
              "Preview your data to ensure correct mapping",
              "Click 'Upload' to complete the process",
            ],
          },
        ],
      },
      {
        type: "tip",
        text: "Quick Tip: Save your field mapping as a template for future uploads to save time!",
      },
      {
        type: "section",
        heading: "Data Validation",
        text: "After upload, Resource Advisor+ will:",
        items: [
          "Check for data quality issues",
          "Identify missing or incorrect values",
          "Flag potential duplicates",
          "Generate a validation report",
        ],
      },
    ],
  },
  "4": {
    title: "Quick start guide to Download Data for Visualizations",
    category: "Data Management",
    readTime: "4 min read",
    lastUpdated: "January 20, 2026",
    content: [
      {
        type: "intro",
        text: "Export your data from Resource Advisor+ for external analysis, reporting, or archiving purposes.",
      },
      {
        type: "section",
        heading: "Export Options",
        text: "Choose from multiple export formats:",
        items: [
          "CSV - Best for data analysis in spreadsheet tools",
          "Excel - Includes formatting and multiple sheets",
          "PDF - For sharing reports and presentations",
          "JSON - For integration with other systems",
        ],
      },
      {
        type: "section",
        heading: "How to Download Data",
        subsections: [
          {
            heading: "Method 1: Quick Export",
            items: [
              "Navigate to any data visualization or report",
              "Click the 'Export' icon in the top right corner",
              "Select your preferred format",
              "Click 'Download'",
            ],
          },
          {
            heading: "Method 2: Custom Export",
            items: [
              "Go to 'Data Management' > 'Export Data'",
              "Select the data range and filters you need",
              "Choose which fields to include",
              "Select output format and download",
            ],
          },
        ],
      },
      {
        type: "section",
        heading: "Advanced Features",
        items: [
          "Schedule automated exports",
          "Set up recurring downloads",
          "Create export templates for consistent formatting",
          "Share exports directly via email",
        ],
      },
      {
        type: "tip",
        text: "Pro Tip: Use scheduled exports to automatically receive weekly or monthly data summaries!",
      },
    ],
  },
  "5": {
    title: "Dashboard and Analytics",
    category: "Analytics",
    readTime: "7 min read",
    lastUpdated: "January 12, 2026",
    content: [
      {
        type: "intro",
        text: "Leverage Resource Advisor+'s powerful analytics dashboard to gain insights into your sustainability performance.",
      },
      {
        type: "section",
        heading: "Dashboard Overview",
        text: "The main dashboard provides at-a-glance visibility into:",
        items: [
          "Key performance indicators (KPIs)",
          "Trends and patterns over time",
          "Comparative analysis across facilities",
          "Alert notifications and recommendations",
        ],
      },
    ],
  },
  "6": {
    title: "Home and Navigation",
    category: "Getting Started",
    readTime: "3 min read",
    lastUpdated: "January 10, 2026",
    content: [
      {
        type: "intro",
        text: "Navigate Resource Advisor+ with ease using this comprehensive guide to the platform's interface and features.",
      },
      {
        type: "section",
        heading: "Main Navigation Menu",
        text: "The left sidebar contains all major sections:",
        items: [
          "Dashboard - Overview of your sustainability metrics",
          "Data Management - Upload, export, and manage your data",
          "Analytics - Advanced reporting and visualizations",
          "SERA AI - Access the AI assistant",
          "Settings - Configure your preferences",
        ],
      },
    ],
  },
};

// Helper function to generate ID from heading
function generateId(heading: string): string {
  return heading.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

export function ArticlePage() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const topicId = searchParams.get("topic");
  const subtopicTitle = searchParams.get("subtopic");
  const article = articles[id as keyof typeof articles];
  const [activeSection, setActiveSection] = useState<string>("");
  const [feedback, setFeedback] = useState<"helpful" | "not-helpful" | null>(null);
  const [showFeedbackMessage, setShowFeedbackMessage] = useState(false);

  // Topic ID to title mapping
  const topicTitles: Record<string, string> = {
    "home-navigation": "Home and Navigation",
    "sera": "SERA",
    "dashboard-analytics": "Dashboard and Analytics",
    "carbon-emissions": "Carbon Footprint and Emissions",
    "supply-chain": "Supply Chain Management",
    "sustainability-esg": "Sustainability and ESG",
  };

  useEffect(() => {
    if (!article) return;

    const handleScroll = () => {
      const sections = article.content
        .filter((section) => section.type === "section")
        .map((section) => {
          if (section.type === "section") {
            const sectionId = generateId(section.heading);
            const element = document.getElementById(sectionId);
            if (element) {
              const rect = element.getBoundingClientRect();
              return {
                id: sectionId,
                top: rect.top,
                heading: section.heading,
              };
            }
          }
          return null;
        })
        .filter(Boolean);

      // Find the section that's currently in view (closest to top of viewport)
      const currentSection = sections.find((section) => {
        if (section) {
          return section.top >= 0 && section.top <= 300;
        }
        return false;
      });

      if (currentSection) {
        setActiveSection(currentSection.id);
      } else if (sections.length > 0 && sections[0]) {
        // If scrolled past all sections, highlight the last one
        const lastVisibleSection = sections
          .filter((s) => s && s.top < 300)
          .pop();
        if (lastVisibleSection) {
          setActiveSection(lastVisibleSection.id);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    handleScroll(); // Call once on mount

    return () => window.removeEventListener("scroll", handleScroll);
  }, [article]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 120; // Offset for fixed header
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      window.scrollTo({
        top: elementPosition - offset,
        behavior: "smooth",
      });
    }
  };

  if (!article) {
    return (
      <div className="bg-[#f5f8fa] min-h-screen">
        <Header />
        <div className="px-[56px] py-[40px]">
          <div className="max-w-[1200px] mx-auto">
            {/* Back to Knowledge Base Link */}
            <Link to="/" className="inline-block mb-[16px]">
              <div className="w-[210px] h-[24px]">
                <BackToKnowledgeBase />
              </div>
            </Link>

            {/* Breadcrumb */}
            <div className="mb-[32px]">
              <Link
                to="/"
                className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
              >
                Homepage
              </Link>
              {topicId && topicTitles[topicId] && (
                <>
                  <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
                  <Link
                    to={`/topic/${topicId}`}
                    className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
                  >
                    {topicTitles[topicId]}
                  </Link>
                </>
              )}
              {subtopicTitle && (
                <>
                  <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
                  <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">{subtopicTitle}</span>
                </>
              )}
            </div>

            <div className="text-center mt-[80px]">
              <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-[#090b0c] mb-[24px]">
                Article Not Found
              </h1>
              <p className="font-['Nunito:Regular',sans-serif] text-[20px] text-[#676f73] mb-[32px]">
                The article you're looking for doesn't exist or has been moved.
              </p>
              <Link
                to="/"
                className="inline-flex items-center gap-[12px] bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#0a9570] transition-colors"
              >
                <ArrowLeft className="size-[20px]" />
                Back to Home
              </Link>

              {/* Help Section */}
              <div className="mt-[80px] bg-[#087959] rounded-[4px] p-[40px] text-white text-center">
                <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] mb-[16px]">
                  Still need help?
                </h2>
                <p className="font-['Nunito:Regular',sans-serif] text-[18px] mb-[24px]">
                  Our support team is here to assist you with any questions.
                </p>
                <Link
                  to="/contact"
                  className="inline-block bg-white text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#f5f8fa] transition-colors"
                >
                  Contact Support
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <Footer />
        
        {/* ChatBot */}
        <ChatBot />
      </div>
    );
  }

  // Extract table of contents from article sections
  const tableOfContents = article.content
    .filter((section) => section.type === "section")
    .map((section) => {
      if (section.type === "section") {
        return {
          id: generateId(section.heading),
          heading: section.heading,
        };
      }
      return null;
    })
    .filter(Boolean);

  return (
    <div className="bg-[#f5f8fa] min-h-screen">
      <Header />
      
      <div className="px-[56px] py-[40px]">
        <div className="max-w-[1600px] mx-auto relative">
          <div className="flex gap-[40px]">
            {/* Main Content */}
            <div className="flex-1 max-w-[1200px]">
              {/* Back to Knowledge Base Link */}
              <Link to="/" className="inline-block mb-[16px]">
                <div className="w-[210px] h-[24px]">
                  <BackToKnowledgeBase />
                </div>
              </Link>

              {/* Breadcrumb */}
              <div className="mb-[32px]">
                <Link
                  to="/"
                  className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
                >
                  Homepage
                </Link>
                {topicId && topicTitles[topicId] && (
                  <>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
                    <Link
                      to={`/topic/${topicId}`}
                      className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
                    >
                      {topicTitles[topicId]}
                    </Link>
                  </>
                )}
                {subtopicTitle && (
                  <>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">{subtopicTitle}</span>
                  </>
                )}
                {!subtopicTitle && (
                  <>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
                    <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">{article.title}</span>
                  </>
                )}
              </div>

              {/* Article Header */}
              <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[48px] mb-[32px]">
                <div className="mb-[24px]">
                  <span className="inline-block bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[16px] py-[8px] rounded-[4px] text-[16px]">
                    {article.category}
                  </span>
                </div>
                
                <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-[#090b0c] mb-[24px] leading-[68px]">
                  {article.title}
                </h1>

                <div className="flex items-center gap-[32px] text-[#676f73] font-['Nunito:Regular',sans-serif] text-[18px]">
                  <div className="flex items-center gap-[8px]">
                    <Clock className="size-[18px]" />
                    {article.readTime}
                  </div>
                  <div className="flex items-center gap-[8px]">
                    <FileText className="size-[18px]" />
                    Last updated: {article.lastUpdated}
                  </div>
                  <div className="flex items-center gap-[8px]">
                    Article Written by: Ian Lawrence, Sustainability Expert
                  </div>
                </div>
              </div>

              {/* Article Content */}
              <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[48px]">
                <div className="prose max-w-none">
                  {article.content.map((section, index) => {
                    if (section.type === "intro") {
                      return (
                        <p key={index} className="font-['Nunito:Regular',sans-serif] text-[20px] text-[#090b0c] leading-[32px] mb-[32px] bg-[#f0f9f7] p-[24px] rounded-[4px] border-l-4 border-[#087959]">
                          {section.text}
                        </p>
                      );
                    }

                    if (section.type === "section") {
                      const sectionId = generateId(section.heading);
                      return (
                        <div key={index} className="mb-[40px]" id={sectionId}>
                          <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[36px] text-[#087959] mb-[16px]">
                            {section.heading}
                          </h2>
                          {section.text && (
                            <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px] mb-[16px]">
                              {section.text}
                            </p>
                          )}
                          {section.items && (
                            <ul className="list-disc pl-[32px] space-y-[12px] mb-[16px]">
                              {section.items.map((item, i) => (
                                <li key={i} className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px]">
                                  {item}
                                </li>
                              ))}
                            </ul>
                          )}
                          {section.subsections && section.subsections.map((subsection, i) => (
                            <div key={i} className="ml-[24px] mb-[24px]">
                              <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[24px] text-[#090b0c] mb-[12px]">
                                {subsection.heading}
                              </h3>
                              {subsection.text && (
                                <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px] mb-[12px]">
                                  {subsection.text}
                                </p>
                              )}
                              {subsection.items && (
                                <ul className="list-disc pl-[32px] space-y-[8px]">
                                  {subsection.items.map((item, j) => (
                                    <li key={j} className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px]">
                                      {item}
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          ))}
                        </div>
                      );
                    }

                    if (section.type === "tip") {
                      return (
                        <div key={index} className="bg-[#fff8e6] border-l-4 border-[#f0ad4e] p-[24px] rounded-[4px] mb-[32px]">
                          <div className="flex items-start gap-[12px]">
                            <BookOpen className="size-[24px] text-[#f0ad4e] flex-shrink-0 mt-[4px]" />
                            <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px]">
                              {section.text}
                            </p>
                          </div>
                        </div>
                      );
                    }

                    return null;
                  })}
                </div>
              </div>

              {/* Feedback Section */}
              <div className="mt-[32px] bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[40px]">
                <div className="text-center">
                  <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[28px] text-[#090b0c] mb-[16px]">
                    Was this article helpful?
                  </h3>
                  <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#676f73] mb-[24px]">
                    Let us know if this article helped you find what you needed.
                  </p>
                  
                  {!feedback ? (
                    <div className="flex gap-[16px] justify-center">
                      <button
                        onClick={() => {
                          setFeedback("helpful");
                          setShowFeedbackMessage(true);
                        }}
                        className="flex items-center gap-[12px] bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#0a9570] transition-colors"
                      >
                        <ThumbsUp className="size-[20px]" />
                        Yes, it was helpful
                      </button>
                      <button
                        onClick={() => {
                          setFeedback("not-helpful");
                          setShowFeedbackMessage(true);
                        }}
                        className="flex items-center gap-[12px] bg-[#676f73] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#4a5155] transition-colors"
                      >
                        <ThumbsDown className="size-[20px]" />
                        No, I need more help
                      </button>
                    </div>
                  ) : (
                    <div className="bg-[#f0f9f7] border border-[#087959] border-solid rounded-[4px] p-[24px]">
                      {feedback === "helpful" ? (
                        <div>
                          <p className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-[#087959] mb-[8px]">
                            Thank you for your feedback!
                          </p>
                          <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">
                            We're glad this article was helpful. Feel free to explore more articles or contact us if you need additional assistance.
                          </p>
                        </div>
                      ) : (
                        <div>
                          <p className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-[#087959] mb-[8px]">
                            We're sorry this didn't help.
                          </p>
                          <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mb-[16px]">
                            Our support team is here to assist you with any questions you may have.
                          </p>
                          <Link
                            to="/contact"
                            className="inline-flex items-center gap-[8px] bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[24px] py-[12px] rounded-[4px] hover:bg-[#0a9570] transition-colors"
                          >
                            Contact Support
                            <ArrowLeft className="size-[16px] rotate-180" />
                          </Link>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Related Articles */}
              <div className="mt-[48px]">
                <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[36px] text-[#090b0c] mb-[24px]">
                  Related Articles
                </h2>
                <div className="grid grid-cols-3 gap-[24px]">
                  {Object.entries(articles)
                    .filter(([key]) => key !== id)
                    .slice(0, 3)
                    .map(([key, relatedArticle]) => (
                      <Link
                        key={key}
                        to={`/article/${key}`}
                        className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[24px] hover:shadow-lg transition-shadow"
                      >
                        <div className="mb-[12px]">
                          <span className="inline-block bg-[#f0f9f7] text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium px-[12px] py-[6px] rounded-[4px] text-[14px]">
                            {relatedArticle.category}
                          </span>
                        </div>
                        <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[20px] text-[#090b0c] mb-[8px] leading-[28px]">
                          {relatedArticle.title}
                        </h3>
                        <p className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73]">
                          {relatedArticle.readTime}
                        </p>
                      </Link>
                    ))}
                </div>
              </div>

              {/* Help Section */}
              <div className="mt-[48px] bg-[#087959] rounded-[4px] p-[40px] text-white">
                <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] mb-[16px]">
                  Still need help?
                </h2>
                <p className="font-['Nunito:Regular',sans-serif] text-[18px] mb-[24px]">
                  Our support team is here to assist you with any questions.
                </p>
                <Link
                  to="/contact"
                  className="inline-block bg-white text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#f5f8fa] transition-colors"
                >
                  Contact Support
                </Link>
              </div>
            </div>

            {/* Table of Contents - Fixed Navigation */}
            {tableOfContents.length > 0 && (
              <div className="w-[280px] flex-shrink-0">
                <div className="sticky top-[180px]">
                  <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[24px]">
                    <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[18px] text-[#090b0c] mb-[16px]">
                      On This Page
                    </h3>
                    <nav>
                      <ul className="space-y-[12px]">
                        {tableOfContents.map((item) => {
                          if (!item) return null;
                          const isActive = activeSection === item.id;
                          return (
                            <li key={item.id}>
                              <button
                                onClick={() => scrollToSection(item.id)}
                                className={`text-left w-full font-['Nunito:Regular',sans-serif] text-[14px] leading-[20px] transition-colors hover:text-[#087959] ${
                                  isActive
                                    ? "text-[#087959] font-bold border-l-2 border-[#087959] pl-[12px] -ml-[2px]"
                                    : "text-[#676f73] pl-[12px]"
                                }`}
                              >
                                {item.heading}
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </nav>
                  </div>

                  {/* Progress Indicator */}
                  <div className="mt-[16px] bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[16px]">
                    <div className="flex items-center gap-[8px] text-[#676f73]">
                      <Clock className="size-[16px]" />
                      <span className="font-['Nunito:Regular',sans-serif] text-[12px]">
                        {article.readTime}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      {/* Footer */}
      <Footer />

      {/* ChatBot */}
      <ChatBot />
    </div>
  );
}