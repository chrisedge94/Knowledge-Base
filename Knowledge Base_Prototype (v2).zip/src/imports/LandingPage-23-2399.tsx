import svgPaths from "./svg-5wwadq0jak";

function Icon() {
  return (
    <div className="relative shrink-0 size-[80px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 80">
        <g clipPath="url(#clip0_23_2403)" id="Icon">
          <path d={svgPaths.p254bb80} fill="var(--fill-0, white)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_23_2403">
            <rect fill="white" height="80" width="80" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

export default function LandingPage() {
  return (
    <div className="bg-[#087959] content-stretch flex items-center justify-center relative rounded-[41943000px] size-full" data-name="LandingPage">
      <Icon />
    </div>
  );
}