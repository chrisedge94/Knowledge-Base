import { Link, useParams } from "react-router-dom";
import svgPaths from "@/imports/svg-m795sxqv7p";
import { Header } from "./Header";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";
import ShareIcon from "@/imports/ShareIcon3";
import BackToKnowledgeBase from "@/imports/Link";

// Subtopics data structure
const topicsData = {
  "home-navigation": {
    title: "Home and Navigation",
    icon: "share",
    subtopics: [
      {
        id: "6",
        title: "Getting Started with Navigation",
        description: "Learn how to navigate the Resource Advisor+ platform",
        icon: "compass",
      },
      {
        id: "navigation-tips",
        title: "Navigation Tips & Tricks",
        description: "Advanced navigation features and shortcuts",
        icon: "share",
      },
      {
        id: "customizing-dashboard",
        title: "Customizing Your Dashboard",
        description: "Personalize your home dashboard layout",
        icon: "upload",
      },
    ],
  },
  "sera": {
    title: "SERA",
    icon: "compass",
    subtopics: [
      {
        id: "1",
        title: "Introduction to SERA AI Assistant",
        description: "Learn the basics of using SERA for sustainability reporting",
        icon: "compass",
      },
      {
        id: "sera-advanced",
        title: "Advanced SERA Features",
        description: "Unlock the full potential of SERA's AI capabilities",
        icon: "share",
      },
      {
        id: "sera-integrations",
        title: "SERA Integrations",
        description: "Connect SERA with your existing tools",
        icon: "download",
      },
    ],
  },
  "dashboard-analytics": {
    title: "Dashboard and Analytics",
    icon: "upload",
    subtopics: [
      {
        id: "5",
        title: "Dashboard Overview",
        description: "Understanding your analytics dashboard",
        icon: "upload",
      },
      {
        id: "custom-reports",
        title: "Creating Custom Reports",
        description: "Build reports tailored to your needs",
        icon: "share",
      },
      {
        id: "data-visualization",
        title: "Data Visualization Techniques",
        description: "Best practices for visualizing your data",
        icon: "compass",
      },
    ],
  },
  "carbon-emissions": {
    title: "Carbon Footprint and Emissions",
    icon: "download",
    subtopics: [
      {
        id: "carbon-tracking",
        title: "Tracking Carbon Emissions",
        description: "Monitor and measure your carbon footprint",
        icon: "download",
      },
      {
        id: "emissions-reporting",
        title: "Emissions Reporting",
        description: "Generate compliance-ready emissions reports",
        icon: "share",
      },
      {
        id: "reduction-strategies",
        title: "Carbon Reduction Strategies",
        description: "Strategies to reduce your carbon footprint",
        icon: "compass",
      },
    ],
  },
  "supply-chain": {
    title: "Supply Chain Management",
    icon: "share",
    subtopics: [
      {
        id: "supply-chain-overview",
        title: "Supply Chain Sustainability",
        description: "Managing sustainable supply chains",
        icon: "share",
      },
      {
        id: "supplier-tracking",
        title: "Supplier Performance Tracking",
        description: "Monitor supplier sustainability metrics",
        icon: "upload",
      },
      {
        id: "supply-chain-risk",
        title: "Supply Chain Risk Assessment",
        description: "Identify and mitigate supply chain risks",
        icon: "download",
      },
    ],
  },
  "sustainability-esg": {
    title: "Sustainability and ESG",
    icon: "compass",
    subtopics: [
      {
        id: "2",
        title: "Foundation of Sustainability and ESG",
        description: "Core concepts and principles of ESG",
        icon: "compass",
      },
      {
        id: "esg-frameworks",
        title: "ESG Reporting Frameworks",
        description: "Understanding major ESG frameworks",
        icon: "share",
      },
      {
        id: "esg-metrics",
        title: "ESG Metrics and KPIs",
        description: "Key performance indicators for ESG",
        icon: "upload",
      },
    ],
  },
};

export function SubTopicsPage() {
  const { topicId } = useParams();
  const topic = topicsData[topicId as keyof typeof topicsData];

  if (!topic) {
    return (
      <div className="bg-[#f5f8fa] min-h-screen">
        <Header />
        <div className="px-[56px] py-[80px]">
          <div className="max-w-[1200px] mx-auto text-center">
            <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-[#090b0c] mb-[24px]">
              Topic Not Found
            </h1>
            <Link
              to="/"
              className="inline-flex items-center gap-[12px] bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#0a9570] transition-colors"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#f5f8fa] min-h-screen">
      <Header />
      
      <div className="px-[56px] py-[40px]">
        <div className="max-w-[1600px] mx-auto">
          {/* Back to Knowledge Base Link */}
          <Link to="/" className="inline-block mb-[16px]">
            <div className="w-[210px] h-[24px]">
              <BackToKnowledgeBase />
            </div>
          </Link>

          {/* Breadcrumb */}
          <div className="mb-[32px]">
            <Link
              to="/"
              className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
            >
              Homepage
            </Link>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">{topic.title}</span>
          </div>

          {/* Page Header */}
          <div className="mb-[48px]">
            <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[60px] text-[#090b0c] mb-[16px] leading-[68px]">
              {topic.title}
            </h1>
            <p className="font-['Nunito:Regular',sans-serif] text-[20px] text-[#676f73]">
              Browse subtopics and find the articles you need
            </p>
          </div>

          {/* Subtopics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-[24px]">
            {topic.subtopics.map((subtopic, index) => (
              <Link
                key={index}
                to={`/article/${subtopic.id}?topic=${topicId}&subtopic=${encodeURIComponent(subtopic.title)}`}
                className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[32px] hover:shadow-lg transition-shadow flex flex-col"
              >
                <div className="size-[50px] flex items-center justify-center flex-shrink-0 mb-[24px]">
                  <div className="bg-[#eff3f9] rounded-full size-[44px] flex items-center justify-center">
                    {subtopic.icon === "share" && (
                      <svg width="24" height="24" viewBox="0 0 32 32" fill="none">
                        <path d={svgPaths.p28dd1f00} fill="#090B0C" />
                      </svg>
                    )}
                    {subtopic.icon === "compass" && (
                      <svg width="20" height="20" viewBox="0 0 27 27" fill="none">
                        <path d={svgPaths.p30fb9600} fill="black" />
                      </svg>
                    )}
                    {subtopic.icon === "upload" && (
                      <div className="w-[24px]">
                        <ShareIcon />
                      </div>
                    )}
                    {subtopic.icon === "download" && (
                      <div className="w-[24px] rotate-180">
                        <ShareIcon />
                      </div>
                    )}
                  </div>
                </div>
                <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[24px] text-[#090b0c] mb-[12px] leading-[32px]">
                  {subtopic.title}
                </h3>
                <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73] leading-[24px]">
                  {subtopic.description}
                </p>
              </Link>
            ))}
          </div>

          {/* Help Section */}
          <div className="mt-[80px] bg-[#087959] rounded-[4px] p-[40px] text-white">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] mb-[16px]">
              Can't find what you're looking for?
            </h2>
            <p className="font-['Nunito:Regular',sans-serif] text-[18px] mb-[24px]">
              Our support team is ready to help you find the right information.
            </p>
            <Link
              to="/contact"
              className="inline-block bg-white text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#f5f8fa] transition-colors"
            >
              Contact Support
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      <ChatBot />
    </div>
  );
}
