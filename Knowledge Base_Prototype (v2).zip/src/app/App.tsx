import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LandingPage } from "@/app/components/LandingPage";
import { ArticlePage } from "@/app/components/ArticlePage";
import { ContactPage } from "@/app/components/ContactPage";
import { SearchResultsPage } from "@/app/components/SearchResultsPage";
import { UserProfilePage } from "@/app/components/UserProfilePage";
import { SubTopicsPage } from "@/app/components/SubTopicsPage";
import { ScrollToTop } from "@/app/components/ScrollToTop";

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/topic/:topicId" element={<SubTopicsPage />} />
        <Route path="/article/:id" element={<ArticlePage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/search" element={<SearchResultsPage />} />
        <Route path="/profile" element={<UserProfilePage />} />
      </Routes>
    </BrowserRouter>
  );
}