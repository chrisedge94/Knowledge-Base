import svgPaths from "./svg-ui339gtimb";

function Icon() {
  return (
    <div className="absolute left-0 size-[15.99px] top-[4.01px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g id="Icon">
          <path d={svgPaths.p3ed50100} id="Vector" stroke="var(--stroke-0, #087959)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M12.6584 7.99479H3.33116" id="Vector_2" stroke="var(--stroke-0, #087959)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
      </svg>
    </div>
  );
}

export default function Link() {
  return (
    <div className="relative size-full" data-name="Link">
      <Icon />
      <p className="absolute css-ew64yg font-['Nunito:Regular',sans-serif] font-normal leading-[24px] left-[23.98px] text-[#087959] text-[16px] top-[-1px]">Back to Knowledge Base</p>
    </div>
  );
}