export function Footer() {
  return (
    <div className="bg-[#fefefe] px-[24px] py-[12px] flex items-center justify-between">
      <p className="font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] text-[16px] text-[#090b0c] leading-[1.4]">
        © 2026 Schneider Electric Industries SAS. All Rights Reserved.
      </p>
      <div className="flex gap-[16px] items-center">
        <p className="font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] text-[12px] text-[#090b0c] leading-[1.4]">
          Privacy Policy
        </p>
        <div className="h-[10px] w-0 border-l border-[#A0A2A7]" />
        <p className="font-['Arial_Rounded_MT_for_SE:Regular',sans-serif] text-[12px] text-[#090b0c] leading-[1.4]">
          Terms of Use
        </p>
      </div>
    </div>
  );
}
