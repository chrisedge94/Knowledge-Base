import svgPaths from "./svg-a3n9vaw84b";

function Group() {
  return (
    <div className="absolute contents inset-[2.4%_3.08%]" data-name="Group">
      <div className="absolute inset-[35.35%_3.08%_2.4%_3.08%]" data-name="Vector">
        <div className="absolute inset-[-3.86%_-3.28%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.3749 20.942">
            <path d={svgPaths.pc574fa0} id="Vector" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_49.99%_46.34%_50.01%]" data-name="Vector_2">
        <div className="absolute inset-[-4.69%_-0.75px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.50103 17.5112">
            <path d="M0.750515 16.7607V0.750515" id="Vector_2" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[2.4%_31.23%_82.95%_31.23%]" data-name="Vector_3">
        <div className="absolute inset-[-16.41%_-8.2%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.6506 6.07537">
            <path d={svgPaths.p1ba5e4c8} id="Vector_3" stroke="var(--stroke-0, #1D201F)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.50103" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[31.233px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <Group />
    </div>
  );
}

function Group1() {
  return (
    <div className="content-stretch flex flex-col h-[31.233px] items-start relative shrink-0 w-full" data-name="Group3">
      <Icon />
    </div>
  );
}

export default function ShareIcon() {
  return (
    <div className="flex items-center justify-center relative size-full" data-name="ShareIcon3">
      <Group1 />
    </div>
  );
}