import { Bell } from "lucide-react";
import { useState, useRef, useEffect } from "react";

export function NotificationsButton() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }

    if (isDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isDropdownOpen]);

  const notifications = [
    {
      id: 1,
      title: "New Sustainability Guidelines",
      description: "Updated best practices for carbon footprint reduction",
      time: "2 hours ago",
    },
    {
      id: 2,
      title: "Renewable Energy Article",
      description: "How to transition to 100% renewable energy",
      time: "5 hours ago",
    },
    {
      id: 3,
      title: "Waste Management Tips",
      description: "Effective strategies for reducing workplace waste",
      time: "1 day ago",
    },
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="bg-[#087959] rounded-full size-[40px] flex items-center justify-center hover:bg-[#0a9570] transition-colors relative"
        aria-label="Notifications"
      >
        <Bell className="size-[20px] text-white" />
        <span className="absolute top-[8px] right-[8px] bg-red-500 rounded-full size-[8px]" />
      </button>

      {isDropdownOpen && (
        <div className="absolute right-0 top-[48px] w-[320px] bg-white rounded-[8px] shadow-lg border border-[#e0e0e0] z-50">
          <div className="p-[16px] border-b border-[#e0e0e0]">
            <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-black">
              Recent Updates
            </h3>
          </div>
          <div className="max-h-[300px] overflow-y-auto">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="p-[16px] border-b border-[#f0f0f0] hover:bg-[#f9f9f9] cursor-pointer transition-colors"
              >
                <h4 className="font-['Nunito:Bold',sans-serif] font-bold text-[14px] text-black mb-[4px]">
                  {notification.title}
                </h4>
                <p className="font-['Nunito:Regular',sans-serif] text-[12px] text-[#666] mb-[4px]">
                  {notification.description}
                </p>
                <span className="font-['Nunito:Regular',sans-serif] text-[11px] text-[#999]">
                  {notification.time}
                </span>
              </div>
            ))}
          </div>
          <div className="p-[12px] text-center border-t border-[#e0e0e0]">
            <button className="font-['Nunito:Bold',sans-serif] font-bold text-[14px] text-[#087959] hover:text-[#0a9570]">
              View All Notifications
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
