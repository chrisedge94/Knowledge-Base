
  # Knowledge Base_Prototype (v2)

  This is a code bundle for Knowledge Base_Prototype (v2). The original project is available at https://www.figma.com/design/aiVM7Qv94XsFecmP6rv5AY/Knowledge-Base_Prototype--v2-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  