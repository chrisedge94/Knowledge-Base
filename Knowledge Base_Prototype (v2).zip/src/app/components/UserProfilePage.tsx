import { Header } from "./Header";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";
import { useState } from "react";

export function UserProfilePage() {
  const [name, setName] = useState("Maria Anderson");
  const [email, setEmail] = useState("maria.anderson@company.com");
  const [sustainabilityTopics, setSustainabilityTopics] = useState({
    carbonReduction: true,
    renewableEnergy: true,
    wasteManagement: false,
    waterConservation: true,
    sustainableSupplyChain: false,
    circularEconomy: true,
  });
  const [emailFrequency, setEmailFrequency] = useState("weekly");

  const handleTopicChange = (topic: keyof typeof sustainabilityTopics) => {
    setSustainabilityTopics(prev => ({
      ...prev,
      [topic]: !prev[topic]
    }));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />
      
      <div className="flex-1 px-[56px] py-[40px] flex flex-col items-center">
        {/* Profile Header */}
        <div className="mb-[40px]">
          <div className="flex items-center gap-[24px] mb-[16px]">
            <div className="rounded-[999px] size-[80px] relative bg-[#676f73] flex items-center justify-center">
              <span className="font-['Nunito_Sans:Bold',sans-serif] font-bold text-[36px] text-white">
                MA
              </span>
            </div>
            <div>
              <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[48px] text-black leading-[56px]">
                Profile Settings
              </h1>
              <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#676f73]">
                Manage your account and preferences
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-[1000px]">
          {/* User Information Section */}
          <div className="mb-[48px] bg-white border border-[#d4d8d9] rounded-[8px] p-[32px]">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] text-black mb-[24px]">
              User Information
            </h2>
            
            <div className="space-y-[24px]">
              <div>
                <label className="block font-['Nunito_Sans:SemiBold',sans-serif] font-semibold text-[18px] text-[#090b0c] mb-[8px]">
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-[56px] bg-white border border-[#676f73] border-solid rounded-[4px] px-[20px] font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c] focus:outline-none focus:border-[#087959]"
                />
              </div>

              <div>
                <label className="block font-['Nunito_Sans:SemiBold',sans-serif] font-semibold text-[18px] text-[#090b0c] mb-[8px]">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-[56px] bg-white border border-[#676f73] border-solid rounded-[4px] px-[20px] font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c] focus:outline-none focus:border-[#087959]"
                />
              </div>
            </div>
          </div>

          {/* Sustainability Preferences Section */}
          <div className="mb-[48px] bg-white border border-[#d4d8d9] rounded-[8px] p-[32px]">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] text-black mb-[12px]">
              Sustainability Article Preferences
            </h2>
            <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73] mb-[24px]">
              Select the topics you're most interested in to personalize your article recommendations
            </p>

            <div className="space-y-[16px]">
              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.carbonReduction}
                  onChange={() => handleTopicChange('carbonReduction')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Carbon Reduction & Climate Action
                </span>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.renewableEnergy}
                  onChange={() => handleTopicChange('renewableEnergy')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Renewable Energy & Clean Technology
                </span>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.wasteManagement}
                  onChange={() => handleTopicChange('wasteManagement')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Waste Management & Recycling
                </span>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.waterConservation}
                  onChange={() => handleTopicChange('waterConservation')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Water Conservation & Management
                </span>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.sustainableSupplyChain}
                  onChange={() => handleTopicChange('sustainableSupplyChain')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Sustainable Supply Chain & Sourcing
                </span>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="checkbox"
                  checked={sustainabilityTopics.circularEconomy}
                  onChange={() => handleTopicChange('circularEconomy')}
                  className="w-[24px] h-[24px] rounded-[4px] border-2 border-[#676f73] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <span className="font-['Nunito_Sans:Regular',sans-serif] text-[18px] text-[#090b0c]">
                  Circular Economy & Product Lifecycle
                </span>
              </label>
            </div>
          </div>

          {/* Email Notification Preferences Section */}
          <div className="mb-[48px] bg-white border border-[#d4d8d9] rounded-[8px] p-[32px]">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[32px] text-black mb-[12px]">
              Email Notification Preferences
            </h2>
            <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73] mb-[24px]">
              Choose how often you'd like to receive updates when new articles are published
            </p>

            <div className="space-y-[16px]">
              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="radio"
                  name="emailFrequency"
                  value="immediately"
                  checked={emailFrequency === 'immediately'}
                  onChange={(e) => setEmailFrequency(e.target.value)}
                  className="w-[24px] h-[24px] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <div>
                  <div className="font-['Nunito_Sans:SemiBold',sans-serif] font-semibold text-[18px] text-[#090b0c]">
                    Immediately
                  </div>
                  <div className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73]">
                    Receive an email as soon as a new article is published
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="radio"
                  name="emailFrequency"
                  value="weekly"
                  checked={emailFrequency === 'weekly'}
                  onChange={(e) => setEmailFrequency(e.target.value)}
                  className="w-[24px] h-[24px] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <div>
                  <div className="font-['Nunito_Sans:SemiBold',sans-serif] font-semibold text-[18px] text-[#090b0c]">
                    Weekly Digest
                  </div>
                  <div className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73]">
                    Receive a weekly summary of new articles every Monday
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-[12px] cursor-pointer hover:bg-[#f0f9f7] p-[12px] rounded-[4px] transition-colors">
                <input
                  type="radio"
                  name="emailFrequency"
                  value="monthly"
                  checked={emailFrequency === 'monthly'}
                  onChange={(e) => setEmailFrequency(e.target.value)}
                  className="w-[24px] h-[24px] text-[#087959] focus:ring-[#087959] cursor-pointer"
                />
                <div>
                  <div className="font-['Nunito_Sans:SemiBold',sans-serif] font-semibold text-[18px] text-[#090b0c]">
                    Monthly Newsletter
                  </div>
                  <div className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73]">
                    Receive a monthly roundup on the first of each month
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end gap-[16px]">
            <button className="h-[56px] px-[32px] bg-white border-2 border-[#087959] rounded-[4px] font-['Nunito_Sans:Bold',sans-serif] font-bold text-[18px] text-[#087959] hover:bg-[#f0f9f7] transition-colors">
              Cancel
            </button>
            <button className="h-[56px] px-[32px] bg-[#087959] rounded-[4px] font-['Nunito_Sans:Bold',sans-serif] font-bold text-[18px] text-white hover:bg-[#0a9570] transition-colors">
              Save Changes
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      <ChatBot />
    </div>
  );
}
