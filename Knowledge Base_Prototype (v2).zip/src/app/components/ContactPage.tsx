import { Link } from "react-router-dom";
import { Header } from "./Header";
import { Mail, Phone, MapPin, Clock, MessageSquare, HelpCircle, Send } from "lucide-react";
import imgImage7 from "figma:asset/87b4d70e637a0645d999eae543620bd263b014f6.png";
import svgPaths from "@/imports/svg-07n4l0j7g2";
import { imgVision } from "@/imports/svg-ecp4b";
import BackToKnowledgeBase from "@/imports/Link";
import { ChatBot } from "./ChatBot";
import { Footer } from "./Footer";

const contactMethods = [
  {
    icon: MessageSquare,
    title: "Live Chat",
    description: "Chat with our support team in real-time",
    action: "Start Chat",
    available: "Available 24/7",
  },
  {
    icon: Mail,
    title: "Email Support",
    description: "Get detailed assistance via email",
    action: "Send Email",
    available: "Response within 24 hours",
  },
  {
    icon: Phone,
    title: "Phone Support",
    description: "Speak directly with our experts",
    action: "Call Now",
    available: "Mon-Fri, 8am-6pm EST",
  },
  {
    icon: HelpCircle,
    title: "Knowledge Base",
    description: "Find answers in our comprehensive guides",
    action: "Browse Articles",
    available: "Available anytime",
  },
];

const supportTopics = [
  "Technical Support",
  "Account & Billing",
  "Data Management",
  "SERA AI Assistant",
  "Sustainability Reporting",
  "ESG Compliance",
  "Training & Onboarding",
  "Feature Request",
  "Bug Report",
  "Other",
];

const officeLocations = [
  {
    city: "Boston, MA",
    address: "800 Federal Street",
    phone: "+1 (978) 975-9600",
    email: "support.us@se.com",
  },
  {
    city: "London, UK",
    address: "Stafford Park 5, Telford",
    phone: "+44 (0) 1952 290 300",
    email: "support.uk@se.com",
  },
  {
    city: "Singapore",
    address: "3 Changi Business Park",
    phone: "+65 6720 4200",
    email: "support.sg@se.com",
  },
];

export function ContactPage() {
  return (
    <div className="bg-[#f5f8fa] min-h-screen">
      <Header />
      
      <div className="px-[56px] py-[40px]">
        <div className="max-w-[1760px] mx-auto">
          {/* Back to Knowledge Base Link */}
          <Link to="/" className="inline-block mb-[16px]">
            <div className="w-[210px] h-[24px]">
              <BackToKnowledgeBase />
            </div>
          </Link>

          {/* Breadcrumb */}
          <div className="mb-[32px]">
            <Link
              to="/"
              className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline decoration-solid"
            >
              Homepage
            </Link>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] mx-[8px]">/</span>
            <span className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">Contact Us</span>
          </div>

          {/* Hero Section */}
          <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[60px] mb-[40px]">
            <div className="max-w-[880px]">
              <h1 className="font-['Nunito:Bold',sans-serif] font-bold text-[85px] text-black leading-[90px] mb-[24px]">
                We're here to help
              </h1>
              <p className="font-['Nunito:Regular',sans-serif] text-[32px] text-[#090b0c] leading-[40px]">
                Our team of experts is ready to assist you with any questions about Resource Advisor+ and sustainability solutions.
              </p>
            </div>
          </div>

          {/* Contact Methods Grid */}
          <div className="mb-[40px]">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[50px] text-black mb-[32px]">
              How would you like to connect?
            </h2>
            <div className="grid grid-cols-4 gap-[24px]">
              {contactMethods.map((method, index) => {
                const Icon = method.icon;
                return (
                  <div
                    key={index}
                    className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[32px] hover:shadow-lg transition-shadow"
                  >
                    <div className="bg-[#087959] w-[80px] h-[80px] rounded-full flex items-center justify-center mb-[24px]">
                      <Icon className="size-[40px] text-white" />
                    </div>
                    <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[24px] text-[#090b0c] mb-[12px]">
                      {method.title}
                    </h3>
                    <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73] leading-[24px] mb-[16px]">
                      {method.description}
                    </p>
                    <div className="flex items-center gap-[8px] mb-[20px]">
                      <Clock className="size-[16px] text-[#087959]" />
                      <span className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#087959]">
                        {method.available}
                      </span>
                    </div>
                    <button className="w-full bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[24px] py-[12px] rounded-[4px] hover:bg-[#0a9570] transition-colors">
                      {method.action}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Contact Form Section */}
          <div className="grid grid-cols-2 gap-[40px] mb-[40px]">
            {/* Contact Form */}
            <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[48px]">
              <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[50px] text-[#087959] mb-[16px]">
                Send us a message
              </h2>
              <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#090b0c] leading-[28px] mb-[32px]">
                Fill out the form below and our team will get back to you within 24 hours.
              </p>

              <form className="space-y-[24px]">
                <div className="grid grid-cols-2 gap-[16px]">
                  <div>
                    <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                      First Name *
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20"
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20"
                    placeholder="john.doe@company.com"
                  />
                </div>

                <div>
                  <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                    Company
                  </label>
                  <input
                    type="text"
                    className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20"
                    placeholder="Your Company Name"
                  />
                </div>

                <div>
                  <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>

                <div>
                  <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                    Topic *
                  </label>
                  <select
                    required
                    className="w-full h-[48px] px-[16px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20 bg-white"
                  >
                    <option value="">Select a topic</option>
                    {supportTopics.map((topic, index) => (
                      <option key={index} value={topic}>
                        {topic}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-['Nunito:Bold',sans-serif] font-bold text-[16px] text-[#090b0c] mb-[8px]">
                    Message *
                  </label>
                  <textarea
                    required
                    rows={6}
                    className="w-full px-[16px] py-[12px] border border-[#d4d8d9] border-solid rounded-[4px] font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] focus:outline-none focus:border-[#087959] focus:ring-2 focus:ring-[#087959] focus:ring-opacity-20 resize-none"
                    placeholder="Please describe your question or issue in detail..."
                  />
                </div>

                <div className="flex items-start gap-[12px]">
                  <input
                    type="checkbox"
                    id="privacy"
                    required
                    className="mt-[4px] size-[20px] rounded border-[#d4d8d9] text-[#087959] focus:ring-[#087959]"
                  />
                  <label htmlFor="privacy" className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73] leading-[20px]">
                    I agree to the processing of my personal data and accept the{" "}
                    <a href="#" className="text-[#087959] underline">
                      Privacy Policy
                    </a>
                    .
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#087959] text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#0a9570] transition-colors flex items-center justify-center gap-[12px]"
                >
                  <Send className="size-[20px]" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Contact Information */}
            <div className="space-y-[24px]">
              {/* Direct Contact Info */}
              <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[40px]">
                <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-[#087959] mb-[24px]">
                  Direct Contact
                </h3>
                <div className="space-y-[24px]">
                  <div className="flex items-start gap-[16px]">
                    <div className="bg-[#f0f9f7] rounded-full p-[12px]">
                      <Mail className="size-[24px] text-[#087959]" />
                    </div>
                    <div>
                      <h4 className="font-['Nunito:Bold',sans-serif] font-bold text-[18px] text-[#090b0c] mb-[4px]">
                        Email Support
                      </h4>
                      <a
                        href="mailto:support@resourceadvisor.com"
                        className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline"
                      >
                        support@resourceadvisor.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-[16px]">
                    <div className="bg-[#f0f9f7] rounded-full p-[12px]">
                      <Phone className="size-[24px] text-[#087959]" />
                    </div>
                    <div>
                      <h4 className="font-['Nunito:Bold',sans-serif] font-bold text-[18px] text-[#090b0c] mb-[4px]">
                        Phone Support
                      </h4>
                      <a
                        href="tel:+19789759600"
                        className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline"
                      >
                        +1 (978) 975-9600
                      </a>
                      <p className="font-['Nunito:Regular',sans-serif] text-[14px] text-[#676f73] mt-[4px]">
                        Monday - Friday, 8am - 6pm EST
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-[16px]">
                    <div className="bg-[#f0f9f7] rounded-full p-[12px]">
                      <MessageSquare className="size-[24px] text-[#087959]" />
                    </div>
                    <div>
                      <h4 className="font-['Nunito:Bold',sans-serif] font-bold text-[18px] text-[#090b0c] mb-[4px]">
                        Live Chat
                      </h4>
                      <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c]">
                        Available 24/7
                      </p>
                      <button className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#087959] hover:underline mt-[4px]">
                        Start a conversation
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Support Tip */}
              <div className="bg-[#fff8e6] border-l-4 border-[#f0ad4e] p-[24px] rounded-[4px]">
                <div className="flex items-start gap-[12px]">
                  <HelpCircle className="size-[24px] text-[#f0ad4e] flex-shrink-0 mt-[4px]" />
                  <div>
                    <h4 className="font-['Nunito:Bold',sans-serif] font-bold text-[18px] text-[#090b0c] mb-[8px]">
                      Quick Tip
                    </h4>
                    <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] leading-[24px]">
                      For the fastest response, contact us directly from within Resource Advisor+. Our in-app support can access your account details to help resolve issues more quickly.
                    </p>
                  </div>
                </div>
              </div>

              {/* Image */}
              <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[24px]">
                <img src={imgImage7} alt="Support Team" className="w-full h-auto rounded-[4px]" />
              </div>
            </div>
          </div>

          {/* Office Locations */}
          <div className="mb-[40px]">
            <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[50px] text-black mb-[32px]">
              Our Office Locations
            </h2>
            <div className="grid grid-cols-3 gap-[24px]">
              {officeLocations.map((office, index) => (
                <div
                  key={index}
                  className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[32px]"
                >
                  <div className="bg-[#087959] w-[80px] h-[80px] rounded-full flex items-center justify-center mb-[20px]">
                    <MapPin className="size-[40px] text-white" />
                  </div>
                  <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[28px] text-[#087959] mb-[16px] text-left">
                    {office.city}
                  </h3>
                  <div className="space-y-[12px]">
                    <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#090b0c] leading-[24px]">
                      {office.address}
                    </p>
                    <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73]">
                      Phone: <a href={`tel:${office.phone.replace(/\s/g, '')}`} className="text-[#087959] hover:underline">{office.phone}</a>
                    </p>
                    <p className="font-['Nunito:Regular',sans-serif] text-[16px] text-[#676f73]">
                      Email: <a href={`mailto:${office.email}`} className="text-[#087959] hover:underline">{office.email}</a>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* FAQ Quick Links */}
          <div className="bg-[#087959] rounded-[4px] p-[48px] text-white mb-[40px]">
            <div className="max-w-[880px]">
              <h2 className="font-['Nunito:Bold',sans-serif] font-bold text-[50px] mb-[16px]">
                Looking for quick answers?
              </h2>
              <p className="font-['Nunito:Regular',sans-serif] text-[24px] mb-[32px] leading-[32px]">
                Visit our Knowledge Hub to find instant solutions to common questions about Resource Advisor+, SERA AI, and sustainability reporting.
              </p>
              <div className="flex gap-[16px]">
                <Link
                  to="/"
                  className="inline-flex items-center bg-white text-[#087959] font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-[#f5f8fa] transition-colors"
                >
                  Browse Knowledge Base
                </Link>
                <button className="inline-flex items-center bg-transparent border-2 border-white text-white font-['Nunito_Sans:Medium',sans-serif] font-medium px-[32px] py-[16px] rounded-[4px] hover:bg-white hover:text-[#087959] transition-colors">
                  Popular Topics
                </button>
              </div>
            </div>
          </div>

          {/* Social Media Follow */}
          <div className="bg-white border border-[#d4d8d9] border-solid rounded-[4px] p-[40px] text-center">
            <h3 className="font-['Nunito:Bold',sans-serif] font-bold text-[38px] text-black mb-[16px]">
              Follow us on Social Media
            </h3>
            <p className="font-['Nunito:Regular',sans-serif] text-[18px] text-[#676f73] mb-[32px]">
              Stay updated with the latest news, tips, and sustainability insights
            </p>
            <div className="flex gap-[32px] justify-center">
              <a href="#" className="size-[80px]" aria-label="Facebook">
                <svg className="size-full" viewBox="0 0 100 100" fill="none">
                  <path d={svgPaths.p25597c80} fill="#087959" />
                </svg>
              </a>
              <a href="#" className="size-[80px]" aria-label="Twitter">
                <svg className="size-full" viewBox="0 0 100 100" fill="none">
                  <path d={svgPaths.p3070b200} fill="#087959" />
                </svg>
              </a>
              <a href="#" className="size-[80px]" aria-label="Instagram">
                <svg className="size-full" viewBox="0 0 100 100" fill="none">
                  <path d={svgPaths.p9aaa540} fill="#087959" />
                </svg>
              </a>
              <a href="#" className="size-[80px]" aria-label="LinkedIn">
                <svg className="size-full" viewBox="0 0 100 100" fill="none">
                  <path d={svgPaths.p24147000} fill="#087959" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />

      {/* ChatBot */}
      <ChatBot />
    </div>
  );
}